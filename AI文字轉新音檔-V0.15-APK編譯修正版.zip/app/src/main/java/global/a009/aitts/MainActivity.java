package global.a009.aitts;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;


import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {

    private TextToSpeech tts;
    private EditText inputText;
    private Spinner voiceFilterSpinner, voiceSpinner, styleSpinner;
    private SeekBar rateSeek, pitchSeek, playbackSeek;
    private TextView statusText, charCount, timeText;
    private LinearLayout audioList;

    private Button previewPlayButton, previewPauseButton, previewResumeButton, previewStopButton;
    private Button createButton, playButton, pauseButton, resumeButton;
    private Button saveArticleButton, savedArticlesButton, recentButton;

    private final List<Voice> voices = new ArrayList<>();
    private final List<Voice> filteredVoices = new ArrayList<>();

    private MediaPlayer player;
    private MediaPlayer previewPlayer;
    private File previewFile;
    private File currentFile;
    private Uri savedAudioUri;
    private SharedPreferences prefs;
    private String previewTextCache = "";

    private static final int CHUNK_SIZE = 2500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("aitts_v015", MODE_PRIVATE);
        setContentView(buildUi());
        initTts();
        refreshAudioList();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root);

        root.addView(text("AI 文字轉新音檔", 28, true));
        root.addView(text("V0.15｜APK編譯修正版", 14, false));

        inputText = new EditText(this);
        inputText.setHint("把要朗讀的文字貼在這裡……");
        inputText.setGravity(Gravity.TOP);
        inputText.setMinHeight(dp(220));
        inputText.setText(prefs.getString("last_text", ""));
        root.addView(inputText, matchWrap());

        charCount = text(inputText.length() + " 字", 13, false);
        charCount.setGravity(Gravity.END);
        root.addView(charCount);

        inputText.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                charCount.setText(s.length() + " 字");
                prefs.edit().putString("last_text", s.toString()).apply();
            }
            public void afterTextChanged(Editable e) {}
        });

        LinearLayout articleRow1 = horizontal();
        saveArticleButton = button("保存文章");
        savedArticlesButton = button("已保存文章");
        articleRow1.addView(saveArticleButton, weight());
        articleRow1.addView(savedArticlesButton, weight());
        root.addView(articleRow1);

        recentButton = button("最近使用文字");
        root.addView(recentButton, matchWrap());

        root.addView(text("聲音分類", 16, true));
        voiceFilterSpinner = new Spinner(this);
        String[] voiceFilters = {"全部中文語音", "👩 女聲", "👨 男聲", "⚪ 未標示"};
        voiceFilterSpinner.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, voiceFilters));
        root.addView(voiceFilterSpinner, matchWrap());

        root.addView(text("可用語音", 16, true));
        voiceSpinner = new Spinner(this);
        root.addView(voiceSpinner, matchWrap());

        voiceFilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshVoiceSpinner();
            }
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        root.addView(text("真人語調模式", 16, true));
        styleSpinner = new Spinner(this);
        String[] styles = {
                "自然真人",
                "溫暖親切",
                "穩重沉著",
                "專業旁白",
                "故事感",
                "活力推廣",
                "柔和療癒"
        };
        styleSpinner.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, styles));
        root.addView(styleSpinner, matchWrap());

        root.addView(text("語速", 16, true));
        rateSeek = new SeekBar(this);
        rateSeek.setMax(150);
        rateSeek.setProgress(45);
        root.addView(rateSeek, matchWrap());

        root.addView(text("音調", 16, true));
        pitchSeek = new SeekBar(this);
        pitchSeek.setMax(100);
        pitchSeek.setProgress(50);
        root.addView(pitchSeek, matchWrap());

        styleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyStylePreset(position);
            }
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        root.addView(text("試聽控制", 18, true));

        LinearLayout p1 = horizontal();
        previewPlayButton = button("▶ 試聽");
        previewPauseButton = button("⏸ 暫停");
        p1.addView(previewPlayButton, weight());
        p1.addView(previewPauseButton, weight());
        root.addView(p1);

        LinearLayout p2 = horizontal();
        previewResumeButton = button("▶ 繼續");
        previewStopButton = button("■ 停止");
        p2.addView(previewResumeButton, weight());
        p2.addView(previewStopButton, weight());
        root.addView(p2);

        createButton = button("產生完整音檔");
        root.addView(createButton, matchWrap());

        statusText = text("語音引擎初始化中……", 14, false);
        root.addView(statusText);

        root.addView(text("完整音檔播放器", 20, true));
        playbackSeek = new SeekBar(this);
        playbackSeek.setMax(1000);
        root.addView(playbackSeek, matchWrap());

        timeText = text("00:00 / 00:00", 14, false);
        timeText.setGravity(Gravity.CENTER);
        root.addView(timeText);

        LinearLayout playRow = horizontal();
        playButton = button("▶ 播放");
        pauseButton = button("⏸ 暫停");
        playRow.addView(playButton, weight());
        playRow.addView(pauseButton, weight());
        root.addView(playRow);

        resumeButton = button("▶ 繼續播放");
        root.addView(resumeButton, matchWrap());
previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
        previewStopButton.setEnabled(true);

        playButton.setEnabled(false);
        pauseButton.setEnabled(false);
        resumeButton.setEnabled(false);

        root.addView(text("已產生音檔", 20, true));
        audioList = new LinearLayout(this);
        audioList.setOrientation(LinearLayout.VERTICAL);
        root.addView(audioList, matchWrap());

        root.addView(text(
                "※ 免費測試版：不登入、不扣點、不需 API Key。長文會自動分段後嘗試合併成單一 WAV。",
                12, false));

        previewPlayButton.setOnClickListener(v -> previewText());
        previewPauseButton.setOnClickListener(v -> pausePreview());
        previewResumeButton.setOnClickListener(v -> resumePreview());
        previewStopButton.setOnClickListener(v -> stopPreview());

        createButton.setOnClickListener(v -> createAudio());
        playButton.setOnClickListener(v -> playAudio());
        pauseButton.setOnClickListener(v -> pauseAudio());
        resumeButton.setOnClickListener(v -> resumeAudio());

        saveArticleButton.setOnClickListener(v -> saveArticle());
        savedArticlesButton.setOnClickListener(v -> showSavedArticles());
        recentButton.setOnClickListener(v -> showRecent());

        playbackSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (player != null) {
                    int dur = player.getDuration();
                    player.seekTo((int)(dur * (seekBar.getProgress() / 1000.0)));
                    updateTime();
                }
            }
        });

        return scroll;
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                statusText.setText("TTS 語音引擎啟動失敗。");
                return;
            }

            int lang = tts.setLanguage(Locale.TAIWAN);
            if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                statusText.setText("手機尚未安裝繁體中文語音資料。");
                return;
            }

            loadVoices();
            statusText.setText("語音引擎已就緒。");
        });
    }

    private void loadVoices() {
        voices.clear();
        Set<Voice> set = tts.getVoices();

        if (set != null) {
            for (Voice v : set) {
                Locale l = v.getLocale();
                if (l != null && "zh".equals(l.getLanguage())) voices.add(v);
            }
        }

        Collections.sort(voices, Comparator.comparing(Voice::getName));
        refreshVoiceSpinner();
    }

    private String detectGender(Voice voice) {
        if (voice == null) return "unknown";
        String n = voice.getName() == null ? "" : voice.getName().toLowerCase(Locale.ROOT);

        String[] femaleHints = {
                "female", "woman", "girl", "fem", "mei", "xiaoxiao",
                "hsiaochen", "hsiaoyu", "yating", "tingting", "huihui",
                "lili", "xiaoyi", "xiaomeng", "xiaohan"
        };

        String[] maleHints = {
                "male", "man", "boy", "yunxi", "yunyang", "yunfeng",
                "yunhao", "kangkang", "zhiyu"
        };

        for (String h : femaleHints) if (n.contains(h)) return "female";
        for (String h : maleHints) if (n.contains(h)) return "male";
        return "unknown";
    }

    private String genderIcon(Voice voice) {
        String g = detectGender(voice);
        if ("female".equals(g)) return "👩 女聲";
        if ("male".equals(g)) return "👨 男聲";
        return "⚪ 未標示";
    }

    private String localeLabel(Locale locale) {
        if (locale == null) return "中文";
        String tag = locale.toLanguageTag();

        if ("zh-TW".equalsIgnoreCase(tag)) return "繁體中文（台灣）";
        if ("zh-HK".equalsIgnoreCase(tag)) return "繁體中文（香港）";
        if ("zh-CN".equalsIgnoreCase(tag)) return "中文（中國）";
        if ("zh-SG".equalsIgnoreCase(tag)) return "中文（新加坡）";

        return tag;
    }

    private void refreshVoiceSpinner() {
        if (voiceSpinner == null || voiceFilterSpinner == null) return;

        filteredVoices.clear();
        int mode = voiceFilterSpinner.getSelectedItemPosition();

        for (Voice v : voices) {
            String gender = detectGender(v);

            boolean include =
                    mode == 0 ||
                    (mode == 1 && "female".equals(gender)) ||
                    (mode == 2 && "male".equals(gender)) ||
                    (mode == 3 && "unknown".equals(gender));

            if (include) filteredVoices.add(v);
        }

        List<String> labels = new ArrayList<>();

        if (filteredVoices.isEmpty()) {
            if (voices.isEmpty()) labels.add("系統預設中文語音");
            else labels.add("此分類沒有可辨識的語音");
        } else {
            for (Voice v : filteredVoices) {
                labels.add(genderIcon(v) + "｜" + localeLabel(v.getLocale()) + "｜" + v.getName());
            }
        }

        voiceSpinner.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
        ));
    }

    private void applyStylePreset(int mode) {
        switch (mode) {
            case 1:
                rateSeek.setProgress(43);
                pitchSeek.setProgress(55);
                break;
            case 2:
                rateSeek.setProgress(38);
                pitchSeek.setProgress(42);
                break;
            case 3:
                rateSeek.setProgress(48);
                pitchSeek.setProgress(48);
                break;
            case 4:
                rateSeek.setProgress(40);
                pitchSeek.setProgress(53);
                break;
            case 5:
                rateSeek.setProgress(60);
                pitchSeek.setProgress(57);
                break;
            case 6:
                rateSeek.setProgress(32);
                pitchSeek.setProgress(52);
                break;
            default:
                rateSeek.setProgress(45);
                pitchSeek.setProgress(50);
                break;
        }
    }

    private String naturalizeText(String input) {
        if (input == null) return "";
        String t = input.trim();

        t = t.replace("\r\n", "\n");
        t = t.replaceAll("\\n{3,}", "\n\n");
        t = t.replaceAll("\\n\\n", "。\n");
        t = t.replaceAll("(?<![。！？!?])\\n", "，");

        t = t.replaceAll("，{2,}", "，");
        t = t.replaceAll("。{2,}", "。");
        t = t.replaceAll("！{2,}", "！");
        t = t.replaceAll("？{2,}", "？");

        return t;
    }

    private void applyTtsSettings() {
        tts.setSpeechRate(0.5f + rateSeek.getProgress() / 100f);
        tts.setPitch(0.5f + pitchSeek.getProgress() / 100f);

        if (!filteredVoices.isEmpty()) {
            int pos = voiceSpinner.getSelectedItemPosition();
            if (pos >= 0 && pos < filteredVoices.size()) tts.setVoice(filteredVoices.get(pos));
        } else if (!voices.isEmpty()) {
            tts.setVoice(voices.get(0));
        } else {
            tts.setLanguage(Locale.TAIWAN);
        }
    }

    private String getTextOrWarn() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "請先輸入文字", Toast.LENGTH_SHORT).show();
            return null;
        }
        return text;
    }

    private void previewText() {
        String text = getTextOrWarn();
        if (text == null) return;

        applyTtsSettings();
        stopPreviewInternal();

        String naturalText = naturalizeText(text);
        previewTextCache = naturalText.length() > 500
                ? naturalText.substring(0, 500)
                : naturalText;

        File dir = getCacheDir();
        previewFile = new File(dir, "preview_" + System.currentTimeMillis() + ".wav");

        String id = "preview_file_" + System.currentTimeMillis();

        previewPlayButton.setEnabled(false);
        previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
        previewStopButton.setEnabled(true);

        statusText.setText("正在準備試聽音檔……");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}

            @Override public void onDone(String utteranceId) {
                runOnUiThread(() -> {
                    try {
                        if (previewPlayer != null) {
                            previewPlayer.release();
                        }

                        previewPlayer = new MediaPlayer();
                        previewPlayer.setDataSource(previewFile.getAbsolutePath());
                        previewPlayer.prepare();

                        previewPlayer.setOnCompletionListener(mp -> {
                            statusText.setText("試聽完成。");
                            previewPlayButton.setEnabled(true);
                            previewPauseButton.setEnabled(false);
                            previewResumeButton.setEnabled(false);
                        });

                        previewPlayer.start();

                        previewPlayButton.setEnabled(false);
                        previewPauseButton.setEnabled(true);
                        previewResumeButton.setEnabled(false);

                        statusText.setText("正在試聽……");

                    } catch (Exception e) {
                        previewPlayButton.setEnabled(true);
                        previewPauseButton.setEnabled(false);
                        previewResumeButton.setEnabled(false);
                        statusText.setText("試聽播放器載入失敗：" + e.getMessage());
                    }
                });
            }

            @Override public void onError(String utteranceId) {
                runOnUiThread(() -> {
                    previewPlayButton.setEnabled(true);
                    previewPauseButton.setEnabled(false);
                    previewResumeButton.setEnabled(false);
                    statusText.setText("試聽音檔產生失敗。");
                });
            }
        });

        int result = tts.synthesizeToFile(
                previewTextCache,
                null,
                previewFile,
                id
        );

        if (result == TextToSpeech.ERROR) {
            previewPlayButton.setEnabled(true);
            previewPauseButton.setEnabled(false);
            previewResumeButton.setEnabled(false);
            statusText.setText("無法開始準備試聽音檔。");
        }
    }

    private void pausePreview() {
        if (previewPlayer != null && previewPlayer.isPlaying()) {
            previewPlayer.pause();
            previewPauseButton.setEnabled(false);
            previewResumeButton.setEnabled(true);
            statusText.setText("試聽已暫停。");
        }
    }

    private void resumePreview() {
        if (previewPlayer != null && !previewPlayer.isPlaying()) {
            try {
                previewPlayer.start();
                previewPauseButton.setEnabled(true);
                previewResumeButton.setEnabled(false);
                statusText.setText("從暫停位置繼續試聽……");
            } catch (Exception e) {
                statusText.setText("無法繼續試聽：" + e.getMessage());
            }
        } else if (previewPlayer == null) {
            Toast.makeText(this, "請先按試聽", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopPreview() {
        stopPreviewInternal();
        statusText.setText("試聽已停止。");
        previewPlayButton.setEnabled(true);
        previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
    }

    private void stopPreviewInternal() {
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
        }

        if (previewPlayer != null) {
            try {
                if (previewPlayer.isPlaying()) {
                    previewPlayer.stop();
                }
            } catch (Exception ignored) {}

            try {
                previewPlayer.release();
            } catch (Exception ignored) {}

            previewPlayer = null;
        }

        if (previewFile != null && previewFile.exists()) {
            try { previewFile.delete(); } catch (Exception ignored) {}
        }

        previewFile = null;
    }

    private List<String> splitText(String text, int maxLen) {
        List<String> parts = new ArrayList<>();
        String remaining = naturalizeText(text);

        while (remaining.length() > maxLen) {
            String head = remaining.substring(0, maxLen);
            int cut = -1;

            for (String sep : new String[]{"。", "！", "？", "；", "，", "\n"}) {
                int pos = head.lastIndexOf(sep);
                if (pos > maxLen * 0.55 && pos > cut) cut = pos + 1;
            }

            if (cut <= 0) cut = maxLen;

            parts.add(remaining.substring(0, cut).trim());
            remaining = remaining.substring(cut).trim();
        }

        if (!remaining.isEmpty()) parts.add(remaining);
        return parts;
    }

    private void createAudio() {
        String text = getTextOrWarn();
        if (text == null) return;

        stopPreview();
        applyTtsSettings();

        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (dir == null) {
            statusText.setText("無法建立音檔目錄。");
            return;
        }
        if (!dir.exists()) dir.mkdirs();

        List<String> parts = splitText(text, CHUNK_SIZE);
        createButton.setEnabled(false);

        List<File> tempFiles = new ArrayList<>();
        synthesizePart(parts, 0, dir, tempFiles, text);
    }

    private void synthesizePart(
            List<String> parts,
            int index,
            File dir,
            List<File> tempFiles,
            String originalText
    ) {
        if (index >= parts.size()) {
            finishLongAudio(dir, tempFiles, originalText);
            return;
        }

        File out = new File(
                dir,
                "tmp_" + System.currentTimeMillis() + "_" + index + ".wav"
        );

        String id = "chunk_" + index + "_" + System.currentTimeMillis();

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {
                runOnUiThread(() ->
                        statusText.setText(
                                "正在產生第 " + (index + 1) + " / " + parts.size() + " 段……"
                        )
                );
            }

            @Override public void onDone(String utteranceId) {
                tempFiles.add(out);
                runOnUiThread(() ->
                        synthesizePart(parts, index + 1, dir, tempFiles, originalText)
                );
            }

            @Override public void onError(String utteranceId) {
                runOnUiThread(() -> {
                    createButton.setEnabled(true);
                    statusText.setText("第 " + (index + 1) + " 段產生失敗。");
                });
            }
        });

        int result = tts.synthesizeToFile(parts.get(index), null, out, id);

        if (result == TextToSpeech.ERROR) {
            createButton.setEnabled(true);
            statusText.setText("無法開始產生第 " + (index + 1) + " 段。");
        }
    }

    private void finishLongAudio(File dir, List<File> tempFiles, String originalText) {
        try {
            File merged = new File(
                    dir,
                    "AI完整語音_" + System.currentTimeMillis() + ".wav"
            );

            mergeWavFiles(tempFiles, merged);

            for (File f : tempFiles) {
                if (f.exists()) f.delete();
            }

            currentFile = merged;
            savedAudioUri = null;

            createButton.setEnabled(true);

            statusText.setText("✅ 完成：" + merged.getName());

            loadPlayer(merged);
            saveRecent(originalText);
            refreshAudioList();

        } catch (Exception e) {
            createButton.setEnabled(true);

            // 合併失敗時保留分段，避免資料全部遺失
            statusText.setText(
                    "各段音檔已產生，但此手機的 WAV 格式無法安全合併。\n" +
                    "已保留 " + tempFiles.size() + " 個分段音檔。"
            );

            refreshAudioList();
        }
    }

    private static class WavInfo {
        byte[] fmt;
        long dataOffset;
        long dataSize;
        int audioFormat;
        int channels;
        int sampleRate;
        int bitsPerSample;
    }

    private int u16le(byte[] b, int off) {
        return (b[off] & 0xff) | ((b[off + 1] & 0xff) << 8);
    }

    private int i32le(byte[] b, int off) {
        return (b[off] & 0xff)
                | ((b[off + 1] & 0xff) << 8)
                | ((b[off + 2] & 0xff) << 16)
                | ((b[off + 3] & 0xff) << 24);
    }

    private WavInfo parseWav(File file) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] id = new byte[4];

            raf.readFully(id);
            if (!"RIFF".equals(new String(id, StandardCharsets.US_ASCII))) {
                throw new IOException("不是 RIFF WAV");
            }

            readIntLE(raf);
            raf.readFully(id);

            if (!"WAVE".equals(new String(id, StandardCharsets.US_ASCII))) {
                throw new IOException("不是 WAVE");
            }

            WavInfo info = new WavInfo();

            while (raf.getFilePointer() + 8 <= raf.length()) {
                raf.readFully(id);
                String chunkId = new String(id, StandardCharsets.US_ASCII);
                long size = Integer.toUnsignedLong(readIntLE(raf));
                long pos = raf.getFilePointer();

                if ("fmt ".equals(chunkId)) {
                    if (size > 1024 * 1024) throw new IOException("fmt 異常");
                    info.fmt = new byte[(int) size];
                    raf.readFully(info.fmt);

                    if (info.fmt.length >= 16) {
                        info.audioFormat = u16le(info.fmt, 0);
                        info.channels = u16le(info.fmt, 2);
                        info.sampleRate = i32le(info.fmt, 4);
                        info.bitsPerSample = u16le(info.fmt, 14);
                    }

                } else if ("data".equals(chunkId)) {
                    info.dataOffset = pos;
                    info.dataSize = Math.min(size, raf.length() - pos);
                    raf.seek(pos + size);

                } else {
                    raf.seek(pos + size);
                }

                if ((size & 1L) == 1L && raf.getFilePointer() < raf.length()) {
                    raf.seek(raf.getFilePointer() + 1);
                }

                if (info.fmt != null && info.dataSize > 0) break;
            }

            if (info.fmt == null || info.dataSize <= 0) {
                throw new IOException("找不到 WAV 音訊資料");
            }

            return info;
        }
    }

    private void mergeWavFiles(List<File> files, File out) throws IOException {
        if (files.isEmpty()) throw new IOException("沒有音檔");

        List<WavInfo> infos = new ArrayList<>();
        WavInfo first = null;
        long total = 0;

        for (File f : files) {
            WavInfo info = parseWav(f);

            if (first == null) {
                first = info;
            } else if (!Arrays.equals(first.fmt, info.fmt)) {
                throw new IOException("WAV 格式不一致");
            }

            infos.add(info);
            total += info.dataSize;
        }

        if (first == null || total <= 0 || total > 0xFFFFFFFFL - 100) {
            throw new IOException("WAV 大小異常");
        }

        try (FileOutputStream fos = new FileOutputStream(out)) {
            fos.write("RIFF".getBytes(StandardCharsets.US_ASCII));

            int fmtPad = (first.fmt.length & 1);
            long riffSize = 4L + 8L + first.fmt.length + fmtPad + 8L + total;

            writeIntLE(fos, (int) riffSize);

            fos.write("WAVE".getBytes(StandardCharsets.US_ASCII));
            fos.write("fmt ".getBytes(StandardCharsets.US_ASCII));
            writeIntLE(fos, first.fmt.length);
            fos.write(first.fmt);

            if (fmtPad == 1) fos.write(0);

            fos.write("data".getBytes(StandardCharsets.US_ASCII));
            writeIntLE(fos, (int) total);

            byte[] buffer = new byte[64 * 1024];

            for (int i = 0; i < files.size(); i++) {
                try (RandomAccessFile raf = new RandomAccessFile(files.get(i), "r")) {
                    WavInfo info = infos.get(i);
                    raf.seek(info.dataOffset);

                    long remain = info.dataSize;

                    while (remain > 0) {
                        int n = raf.read(
                                buffer,
                                0,
                                (int) Math.min(buffer.length, remain)
                        );

                        if (n < 0) throw new EOFException();

                        fos.write(buffer, 0, n);
                        remain -= n;
                    }
                }
            }
        }
    }

    private int readIntLE(RandomAccessFile raf) throws IOException {
        int b0 = raf.read();
        int b1 = raf.read();
        int b2 = raf.read();
        int b3 = raf.read();

        if ((b0 | b1 | b2 | b3) < 0) throw new EOFException();

        return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
    }

    private void writeIntLE(OutputStream out, int value) throws IOException {
        out.write(value & 0xff);
        out.write((value >>> 8) & 0xff);
        out.write((value >>> 16) & 0xff);
        out.write((value >>> 24) & 0xff);
    }

    private void loadPlayer(File file) {
        try {
            if (player != null) player.release();

            player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.prepare();

            currentFile = file;

            playButton.setEnabled(true);
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(true);

            playbackSeek.setProgress(0);
            updateTime();

            player.setOnCompletionListener(mp -> {
                playbackSeek.setProgress(1000);
                updateTime();
                statusText.setText("播放完成。");
            });

        } catch (Exception e) {
            statusText.setText("播放器載入失敗：" + e.getMessage());
        }
    }

    private void playAudio() {
        if (player == null) return;

        if (!player.isPlaying()) {
            player.start();
            statusText.setText("正在播放音檔……");
            updateProgressLoop();
        }
    }

    private void pauseAudio() {
        if (player != null && player.isPlaying()) {
            player.pause();
            statusText.setText("播放已暫停。");
            updateTime();
        }
    }

    private void resumeAudio() {
        if (player != null && !player.isPlaying()) {
            player.start();
            statusText.setText("繼續播放……");
            updateProgressLoop();
        }
    }

    private void updateProgressLoop() {
        if (player == null) return;

        try {
            int dur = player.getDuration();
            int pos = player.getCurrentPosition();

            if (dur > 0) {
                playbackSeek.setProgress((int) (pos / (double) dur * 1000));
            }

            updateTime();

            if (player.isPlaying()) {
                playbackSeek.postDelayed(this::updateProgressLoop, 500);
            }

        } catch (Exception ignored) {}
    }

    private void updateTime() {
        if (player == null) return;

        timeText.setText(
                formatTime(player.getCurrentPosition()) +
                " / " +
                formatTime(player.getDuration())
        );
    }

    private String formatTime(int ms) {
        int sec = Math.max(0, ms / 1000);

        return String.format(
                Locale.TAIWAN,
                "%02d:%02d",
                sec / 60,
                sec % 60
        );
    }

    private void saveAudioToDownloads() {
        showDownloadFormatDialog();
    }

    private void showDownloadFormatDialog() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "請先選擇或產生音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] formats = {
                "WAV（無損原始音檔）",
                "MP3（128 kbps，較小檔案）"
        };

        new AlertDialog.Builder(this)
                .setTitle("選擇下載格式")
                .setItems(formats, (d, which) -> {
                    if (which == 0) {
                        saveWavToDownloads();
                    } else {
                        saveMp3ToDownloads();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void saveWavToDownloads() {
        String baseName = currentFile.getName();

        if (!baseName.toLowerCase(Locale.ROOT).endsWith(".wav")) {
            baseName += ".wav";
        }

        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, baseName);
            values.put(MediaStore.Downloads.MIME_TYPE, "audio/wav");
            values.put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/AI文字轉新音檔"
            );

            Uri uri = getContentResolver().insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri == null) throw new IOException("建立下載檔失敗");

            try (
                    InputStream in = new FileInputStream(currentFile);
                    OutputStream out = getContentResolver().openOutputStream(uri)
            ) {
                if (out == null) throw new IOException("無法寫入下載資料夾");

                byte[] buffer = new byte[8192];
                int len;

                while ((len = in.read(buffer)) > 0) {
                    out.write(buffer, 0, len);
                }
            }

            savedAudioUri = uri;

            statusText.setText(
                    "✅ WAV 已儲存到 Download/AI文字轉新音檔/\\n" + baseName
            );

            Toast.makeText(
                    this,
                    "WAV 音檔已儲存到下載資料夾",
                    Toast.LENGTH_LONG
            ).show();

        } catch (Exception e) {
            statusText.setText("WAV 儲存失敗：" + e.getMessage());
        }
    }

    private void saveMp3ToDownloads() {
        statusText.setText("正在轉換 MP3……");

        new Thread(() -> {
            File tempMp3 = null;

            try {
                File cacheDir = getCacheDir();

                String stem = currentFile.getName();
                if (stem.toLowerCase(Locale.ROOT).endsWith(".wav")) {
                    stem = stem.substring(0, stem.length() - 4);
                }

                tempMp3 = new File(
                        cacheDir,
                        stem + "_" + System.currentTimeMillis() + ".mp3"
                );

                wavToMp3(currentFile, tempMp3, 128);

                final File finalTempMp3 = tempMp3;
                final String outName = stem + ".mp3";

                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, outName);
                values.put(MediaStore.Downloads.MIME_TYPE, "audio/mpeg");
                values.put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/AI文字轉新音檔"
                );

                Uri uri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                );

                if (uri == null) {
                    throw new IOException("建立 MP3 下載檔失敗");
                }

                try (
                        InputStream in = new FileInputStream(finalTempMp3);
                        OutputStream out = getContentResolver().openOutputStream(uri)
                ) {
                    if (out == null) throw new IOException("無法寫入 MP3");

                    byte[] buffer = new byte[8192];
                    int len;

                    while ((len = in.read(buffer)) > 0) {
                        out.write(buffer, 0, len);
                    }
                }

                savedAudioUri = uri;

                runOnUiThread(() -> {
                    statusText.setText(
                            "✅ MP3 已儲存到 Download/AI文字轉新音檔/\\n" + outName
                    );

                    Toast.makeText(
                            this,
                            "MP3 音檔已儲存到下載資料夾",
                            Toast.LENGTH_LONG
                    ).show();
                });

                try { finalTempMp3.delete(); } catch (Exception ignored) {}

            } catch (Exception e) {
                final String msg = e.getMessage() == null
                        ? e.getClass().getSimpleName()
                        : e.getMessage();

                runOnUiThread(() ->
                        statusText.setText("MP3 轉換失敗：" + msg)
                );

                if (tempMp3 != null && tempMp3.exists()) {
                    try { tempMp3.delete(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    private void wavToMp3(File wav, File mp3, int bitrateKbps) throws IOException {
        WavInfo info = parseWav(wav);

        if (info.audioFormat != 1) {
            throw new IOException("目前僅支援 PCM WAV 轉 MP3");
        }

        if (info.bitsPerSample != 16) {
            throw new IOException("目前僅支援 16-bit WAV 轉 MP3");
        }

        if (info.channels < 1 || info.channels > 2) {
            throw new IOException("目前僅支援單聲道或雙聲道");
        }

        if (info.sampleRate <= 0) {
            throw new IOException("WAV 採樣率異常");
        }

        AndroidLame encoder = new LameBuilder()
                .setInSampleRate(info.sampleRate)
                .setOutChannels(info.channels)
                .setOutBitrate(bitrateKbps)
                .setOutSampleRate(info.sampleRate)
                .setQuality(5)
                .build();

        byte[] pcmBytes = new byte[8192];
        short[] left = new short[4096];
        short[] right = new short[4096];
        byte[] mp3Buffer = new byte[(int) (7200 + left.length * 2 * 1.25)];

        try (
                RandomAccessFile raf = new RandomAccessFile(wav, "r");
                BufferedOutputStream out = new BufferedOutputStream(
                        new FileOutputStream(mp3),
                        8192
                )
        ) {
            raf.seek(info.dataOffset);
            long remain = info.dataSize;

            while (remain > 0) {
                int want = (int) Math.min(pcmBytes.length, remain);
                int read = raf.read(pcmBytes, 0, want);

                if (read <= 0) break;

                int frameBytes = info.channels * 2;
                int usable = read - (read % frameBytes);
                int frames = usable / frameBytes;

                for (int frame = 0; frame < frames; frame++) {
                    int base = frame * frameBytes;

                    short l = (short) (
                            (pcmBytes[base] & 0xff) |
                            (pcmBytes[base + 1] << 8)
                    );

                    left[frame] = l;

                    if (info.channels == 2) {
                        int rBase = base + 2;
                        right[frame] = (short) (
                                (pcmBytes[rBase] & 0xff) |
                                (pcmBytes[rBase + 1] << 8)
                        );
                    } else {
                        right[frame] = l;
                    }
                }

                int encoded = encoder.encode(
                        left,
                        right,
                        frames,
                        mp3Buffer
                );

                if (encoded < 0) {
                    throw new IOException("MP3 編碼失敗，錯誤碼：" + encoded);
                }

                if (encoded > 0) {
                    out.write(mp3Buffer, 0, encoded);
                }

                remain -= read;
            }

            int flushed = encoder.lameFlush(mp3Buffer);

            if (flushed < 0) {
                throw new IOException("MP3 收尾失敗，錯誤碼：" + flushed);
            }

            if (flushed > 0) {
                out.write(mp3Buffer, 0, flushed);
            }

            out.flush();

        }

        if (!mp3.exists() || mp3.length() <= 0) {
            throw new IOException("MP3 檔案沒有成功產生");
        }
    }

    private void showShareFormatDialog() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "請先選擇或產生音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] formats = {
                "WAV（無損原始音檔）",
                "MP3（128 kbps）"
        };

        new AlertDialog.Builder(this)
                .setTitle("選擇分享格式")
                .setItems(formats, (dialog, which) -> {
                    if (which == 0) {
                        prepareWavForShare();
                    } else {
                        prepareMp3ForShare();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void prepareWavForShare() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "找不到音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Uri uri = copyAudioToDownloadsForShare(
                    currentFile,
                    ensureExtension(currentFile.getName(), ".wav"),
                    "audio/wav"
            );

            shareUri(uri, "audio/wav");

        } catch (Exception e) {
            statusText.setText("WAV 分享準備失敗：" + safeMessage(e));
        }
    }

    private void prepareMp3ForShare() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "找不到音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText("正在準備 MP3 分享檔……");

        new Thread(() -> {
            File tempMp3 = null;

            try {
                String stem = stripAudioExtension(currentFile.getName());

                tempMp3 = new File(
                        getCacheDir(),
                        stem + "_share_" + System.currentTimeMillis() + ".mp3"
                );

                wavToMp3(currentFile, tempMp3, 128);

                Uri uri = copyAudioToDownloadsForShare(
                        tempMp3,
                        stem + ".mp3",
                        "audio/mpeg"
                );

                File finalTempMp3 = tempMp3;

                runOnUiThread(() -> {
                    statusText.setText("✅ MP3 分享檔已準備完成");
                    shareUri(uri, "audio/mpeg");
                });

                try {
                    finalTempMp3.delete();
                } catch (Exception ignored) {}

            } catch (Exception e) {
                String msg = safeMessage(e);

                runOnUiThread(() ->
                        statusText.setText("MP3 分享準備失敗：" + msg)
                );

                if (tempMp3 != null && tempMp3.exists()) {
                    try {
                        tempMp3.delete();
                    } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    private Uri copyAudioToDownloadsForShare(
            File source,
            String displayName,
            String mimeType
    ) throws IOException {

        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, displayName);
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        values.put(
                MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/AI文字轉新音檔"
        );

        Uri uri = getContentResolver().insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
        );

        if (uri == null) {
            throw new IOException("無法建立分享音檔");
        }

        try (
                InputStream in = new FileInputStream(source);
                OutputStream out = getContentResolver().openOutputStream(uri)
        ) {
            if (out == null) {
                throw new IOException("無法寫入分享音檔");
            }

            byte[] buffer = new byte[8192];
            int len;

            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }

            out.flush();
        }

        return uri;
    }

    private void shareUri(Uri uri, String mimeType) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType(mimeType);
        shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(
                shareIntent,
                "分享音檔"
        ));
    }

    private String stripAudioExtension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);

        if (lower.endsWith(".wav") || lower.endsWith(".mp3")) {
            return name.substring(0, name.length() - 4);
        }

        return name;
    }

    private String ensureExtension(String name, String extension) {
        if (name.toLowerCase(Locale.ROOT)
                .endsWith(extension.toLowerCase(Locale.ROOT))) {
            return name;
        }

        return stripAudioExtension(name) + extension;
    }

    private String safeMessage(Throwable throwable) {
        if (throwable == null) return "未知錯誤";

        String message = throwable.getMessage();

        if (message == null || message.trim().isEmpty()) {
            return throwable.getClass().getSimpleName();
        }

        return message;
    }

    private void shareAudio() {
        showShareFormatDialog();
    }

    private void saveArticle() {
        String text = getTextOrWarn();
        if (text == null) return;

        EditText name = new EditText(this);
        name.setHint("文章名稱");

        new AlertDialog.Builder(this)
                .setTitle("保存文章")
                .setView(name)
                .setPositiveButton("保存", (d, w) -> {
                    String n = name.getText().toString().trim();

                    if (n.isEmpty()) {
                        n = "文章_" + System.currentTimeMillis();
                    }

                    Set<String> names = new LinkedHashSet<>(
                            prefs.getStringSet("article_names", new LinkedHashSet<>())
                    );

                    names.add(n);

                    prefs.edit()
                            .putStringSet("article_names", names)
                            .putString("article_" + n, text)
                            .apply();

                    Toast.makeText(this, "文章已保存", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showSavedArticles() {
        Set<String> saved = prefs.getStringSet(
                "article_names",
                new LinkedHashSet<>()
        );

        if (saved == null || saved.isEmpty()) {
            Toast.makeText(this, "尚無已保存文章", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> names = new ArrayList<>(saved);
        Collections.sort(names);

        new AlertDialog.Builder(this)
                .setTitle("已保存文章")
                .setItems(
                        names.toArray(new String[0]),
                        (d, which) -> showArticleActions(names.get(which))
                )
                .setNegativeButton("關閉", null)
                .show();
    }

    private void showArticleActions(String name) {
        String[] actions = {"載入文章", "刪除文章"};

        new AlertDialog.Builder(this)
                .setTitle(name)
                .setItems(actions, (d, which) -> {
                    if (which == 0) {
                        String t = prefs.getString("article_" + name, "");
                        inputText.setText(t);
                        inputText.setSelection(inputText.length());

                    } else {
                        Set<String> names = new LinkedHashSet<>(
                                prefs.getStringSet("article_names", new LinkedHashSet<>())
                        );

                        names.remove(name);

                        prefs.edit()
                                .putStringSet("article_names", names)
                                .remove("article_" + name)
                                .apply();

                        Toast.makeText(this, "文章已刪除", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void saveRecent(String text) {
        List<String> items = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            String old = prefs.getString("recent_" + i, null);

            if (old != null && !old.equals(text)) {
                items.add(old);
            }
        }

        items.add(0, text);

        while (items.size() > 10) {
            items.remove(items.size() - 1);
        }

        SharedPreferences.Editor e = prefs.edit();

        for (int i = 0; i < 10; i++) {
            e.remove("recent_" + i);
        }

        for (int i = 0; i < items.size(); i++) {
            e.putString("recent_" + i, items.get(i));
        }

        e.apply();
    }

    private void showRecent() {
        List<String> texts = new ArrayList<>();
        List<String> labels = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            String t = prefs.getString("recent_" + i, null);

            if (t != null && !t.isEmpty()) {
                texts.add(t);
                labels.add(
                        t.length() > 35
                                ? t.substring(0, 35) + "…"
                                : t
                );
            }
        }

        if (texts.isEmpty()) {
            Toast.makeText(this, "尚無最近文字", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("最近使用文字")
                .setItems(
                        labels.toArray(new String[0]),
                        (d, which) -> {
                            inputText.setText(texts.get(which));
                            inputText.setSelection(inputText.length());
                        }
                )
                .setNegativeButton("關閉", null)
                .show();
    }

    private void refreshAudioList() {
        if (audioList == null) return;

        audioList.removeAllViews();

        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);

        if (dir == null || !dir.exists()) {
            audioList.addView(text("尚無音檔。", 14, false));
            return;
        }

        File[] files = dir.listFiles((d, n) ->
                n.toLowerCase(Locale.ROOT).endsWith(".wav") &&
                !n.startsWith("tmp_")
        );

        if (files == null || files.length == 0) {
            audioList.addView(text("尚無音檔。", 14, false));
            return;
        }

        Arrays.sort(
                files,
                (a, b) -> Long.compare(b.lastModified(), a.lastModified())
        );

        for (File file : files) {
            addAudioRow(file);
        }
    }

    private void addAudioRow(File file) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(8));

        TextView name = text(file.getName(), 14, true);
        box.addView(name);

        LinearLayout row1 = horizontal();

        Button play = button("播放");
        Button save = button("下載");
        Button share = button("分享");

        row1.addView(play, weight());
        row1.addView(save, weight());
        row1.addView(share, weight());

        box.addView(row1);

        LinearLayout row2 = horizontal();

        Button rename = button("改名");
        Button delete = button("刪除");

        row2.addView(rename, weight());
        row2.addView(delete, weight());

        box.addView(row2);

        play.setOnClickListener(v -> {
            savedAudioUri = null;
            loadPlayer(file);
            playAudio();
        });

        save.setOnClickListener(v -> {
            currentFile = file;
            savedAudioUri = null;
            showDownloadFormatDialog();
        });

        share.setOnClickListener(v -> {
            currentFile = file;
            savedAudioUri = null;
            showShareFormatDialog();
        });

        rename.setOnClickListener(v -> renameAudio(file));
        delete.setOnClickListener(v -> deleteAudio(file));

        audioList.addView(box);
    }

    private void renameAudio(File file) {
        EditText input = new EditText(this);

        String old = file.getName();
        if (old.toLowerCase(Locale.ROOT).endsWith(".wav")) {
            old = old.substring(0, old.length() - 4);
        }

        input.setText(old);

        new AlertDialog.Builder(this)
                .setTitle("重新命名")
                .setView(input)
                .setPositiveButton("確定", (d, w) -> {
                    String name = input.getText().toString().trim();

                    if (name.isEmpty()) return;

                    name = name.replaceAll("[\\\\/:*?\"<>|]", "_");

                    File target = new File(
                            file.getParentFile(),
                            name + ".wav"
                    );

                    if (target.exists()) {
                        Toast.makeText(this, "已有同名檔案", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (file.renameTo(target)) {
                        if (currentFile != null && currentFile.equals(file)) {
                            currentFile = target;
                        }

                        refreshAudioList();

                    } else {
                        Toast.makeText(this, "重新命名失敗", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void deleteAudio(File file) {
        new AlertDialog.Builder(this)
                .setTitle("刪除音檔")
                .setMessage("確定刪除「" + file.getName() + "」？")
                .setPositiveButton("刪除", (d, w) -> {
                    if (currentFile != null && currentFile.equals(file)) {
                        if (player != null) {
                            try {
                                player.stop();
                            } catch (Exception ignored) {}

                            player.release();
                            player = null;
                        }

                        currentFile = null;

                        previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
        previewStopButton.setEnabled(true);

        playButton.setEnabled(false);
                        pauseButton.setEnabled(false);
                        resumeButton.setEnabled(false);
                                                    }

                    if (file.delete()) {
                        refreshAudioList();
                    } else {
                        Toast.makeText(this, "刪除失敗", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setPadding(0, dp(6), 0, dp(6));

        if (bold) {
            v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }

        return v;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int v) {
        return (int) (
                v * getResources().getDisplayMetrics().density
        );
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }

        if (player != null) {
            player.release();
        }

        if (previewPlayer != null) {
            try { previewPlayer.release(); } catch (Exception ignored) {}
        }

        if (previewFile != null && previewFile.exists()) {
            try { previewFile.delete(); } catch (Exception ignored) {}
        }

        super.onDestroy();
    }
}
