AI文字轉新音檔 V0.4.2｜GitHub 自動產生 APK 版
=============================================

這一版是從 V0.3 免費測試版升級。

V0.3 原有功能
- 長文自動分段
- 多段 WAV 自動合併成完整單一音檔
- 播放進度
- 暫停 / 繼續
- 保存文章
- 最近使用文字
- 播放 / 分享 / 改名 / 刪除音檔
- 不收費
- 不扣點
- 不登入
- 不需要 API Key
- 不需要伺服器

V0.4 新增
- GitHub Actions 自動編譯 Android APK
- 每次 push 到 main / master 自動 Build
- 也可在 GitHub Actions 手動按 Run workflow
- 編譯完成後可直接下載 APK Artifact
- Artifact 保留 30 天

GitHub 上傳方式
1. 到 https://github.com/
2. 建立新的 Repository
3. 建議 Repository 名稱：
   ai-text-to-audio
4. 把本專案「解壓縮後的所有檔案」上傳到 Repository 根目錄
5. 確認包含：
   .github/workflows/build-apk.yml
6. Commit changes

自動產生 APK
1. 進入 Repository
2. 點 Actions
3. 點 Build Android APK
4. 若 push 後沒有自動執行：
   點 Run workflow
5. 等待綠色完成
6. 點進該次 Workflow
7. 在 Artifacts 區塊下載：
   AI文字轉新音檔-V0.4.2-APK
8. 解壓縮後會得到：
   AI文字轉新音檔-V0.4.2-免費測試版.apk

APK 使用
- Android 8.0 以上
- Package：global.a009.aitts
- versionCode：5
- versionName：0.4.1

重要
GitHub Artifact 下載下來通常是一個 ZIP，
要先解壓縮，裡面才是真正的 APK。

如果 Android 手機阻擋安裝，
請到系統設定允許該瀏覽器或檔案管理器安裝未知來源 App。
