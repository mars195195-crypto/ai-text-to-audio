package global.a009.aitts;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ViewGroup;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private TextToSpeech tts;
    private EditText inputText;
    private Spinner voiceSpinner;
    private SeekBar rateSeek, pitchSeek, playbackSeek;
    private TextView rateValue, pitchValue, charCount, statusText, timeText;
    private Button previewButton, createButton, playButton, pauseButton, shareButton, saveArticleButton, loadRecentButton, loadSavedButton;
    private LinearLayout fileList;

    private final List<Voice> voices = new ArrayList<>();
    private MediaPlayer mediaPlayer;
    private File currentAudioFile;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean userSeeking = false;
    private SharedPreferences prefs;

    private final Runnable progressUpdater = new Runnable() {
        @Override public void run() {
            if (mediaPlayer != null) {
                try {
                    int dur = mediaPlayer.getDuration();
                    int pos = mediaPlayer.getCurrentPosition();
                    if (!userSeeking && dur > 0) playbackSeek.setProgress((int)((pos / (double)dur) * 1000));
                    timeText.setText(formatTime(pos) + " / " + formatTime(dur));
                    if (mediaPlayer.isPlaying()) handler.postDelayed(this, 500);
                } catch (Exception ignored) {}
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("aitts_v03", MODE_PRIVATE);

        inputText = findViewById(R.id.inputText);
        voiceSpinner = findViewById(R.id.voiceSpinner);
        rateSeek = findViewById(R.id.rateSeek);
        pitchSeek = findViewById(R.id.pitchSeek);
        playbackSeek = findViewById(R.id.playbackSeek);
        rateValue = findViewById(R.id.rateValue);
        pitchValue = findViewById(R.id.pitchValue);
        charCount = findViewById(R.id.charCount);
        statusText = findViewById(R.id.statusText);
        timeText = findViewById(R.id.timeText);
        previewButton = findViewById(R.id.previewButton);
        createButton = findViewById(R.id.createButton);
        playButton = findViewById(R.id.playButton);
        pauseButton = findViewById(R.id.pauseButton);
        shareButton = findViewById(R.id.shareButton);
        saveArticleButton = findViewById(R.id.saveArticleButton);
        loadRecentButton = findViewById(R.id.loadRecentButton);\n        loadSavedButton = findViewById(R.id.loadSavedButton);
        fileList = findViewById(R.id.fileList);

        inputText.setText(prefs.getString("last_text", ""));

        setupListeners();
        initTts();
        refreshFileList();
    }

    private void setupListeners() {
        inputText.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                charCount.setText(s.length() + " 字");
                prefs.edit().putString("last_text", s.toString()).apply();
            }
            public void afterTextChanged(Editable e) {}
        });

        rateSeek.setOnSeekBarChangeListener(simpleSeek(() ->
            rateValue.setText(String.format(Locale.TAIWAN, "%.1fx", getRate()))
        ));

        pitchSeek.setOnSeekBarChangeListener(simpleSeek(() ->
            pitchValue.setText(String.format(Locale.TAIWAN, "%.1f", getPitch()))
        ));

        playbackSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && mediaPlayer != null) {
                    int dur = mediaPlayer.getDuration();
                    timeText.setText(formatTime((int)(dur * (p / 1000.0))) + " / " + formatTime(dur));
                }
            }
            public void onStartTrackingTouch(SeekBar s) { userSeeking = true; }
            public void onStopTrackingTouch(SeekBar s) {
                userSeeking = false;
                if (mediaPlayer != null) {
                    int dur = mediaPlayer.getDuration();
                    mediaPlayer.seekTo((int)(dur * (s.getProgress()/1000.0)));
                }
            }
        });

        previewButton.setOnClickListener(v -> preview());
        createButton.setOnClickListener(v -> createMergedAudio());
        playButton.setOnClickListener(v -> playCurrent());
        pauseButton.setOnClickListener(v -> pauseCurrent());
        shareButton.setOnClickListener(v -> {
            if (currentAudioFile != null) shareFile(currentAudioFile);
        });
        saveArticleButton.setOnClickListener(v -> saveArticle());
        loadRecentButton.setOnClickListener(v -> showRecentTexts());\n        loadSavedButton.setOnClickListener(v -> showSavedArticles());
    }

    private SeekBar.OnSeekBarChangeListener simpleSeek(Runnable r) {
        return new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) { r.run(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        };
    }

    private float getRate() { return 0.5f + rateSeek.getProgress() / 100f; }
    private float getPitch() { return 0.5f + pitchSeek.getProgress() / 100f; }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int lang = tts.setLanguage(Locale.TAIWAN);
                if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                    statusText.setText("目前沒有繁體中文語音，請先安裝中文 TTS 語音資料。");
                } else {
                    loadVoices();
                    statusText.setText("語音引擎已就緒。");
                }
            } else {
                statusText.setText("TTS 語音引擎啟動失敗。");
            }
        });
    }

    private void loadVoices() {
        voices.clear();
        Set<Voice> set = tts.getVoices();
        if (set != null) {
            for (Voice v : set) {
                Locale l = v.getLocale();
                if (l != null && "zh".equals(l.getLanguage())) voices.add(v);
            }
        }
        voices.sort(Comparator.comparing(Voice::getName));

        List<String> labels = new ArrayList<>();
        if (voices.isEmpty()) {
            labels.add("系統預設中文語音");
        } else {
            for (Voice v : voices) labels.add(v.getName() + "｜" + v.getLocale().toLanguageTag());
        }
        voiceSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
    }

    private void applySettings() {
        tts.setSpeechRate(getRate());
        tts.setPitch(getPitch());
        if (!voices.isEmpty()) {
            int pos = voiceSpinner.getSelectedItemPosition();
            if (pos >= 0 && pos < voices.size()) tts.setVoice(voices.get(pos));
        } else {
            tts.setLanguage(Locale.TAIWAN);
        }
    }

    private String getTextOrWarn() {
        String t = inputText.getText().toString().trim();
        if (t.isEmpty()) {
            Toast.makeText(this, "請先輸入文字", Toast.LENGTH_SHORT).show();
            return null;
        }
        return t;
    }

    private void preview() {
        String t = getTextOrWarn();
        if (t == null) return;
        applySettings();
        String preview = t.length() > 500 ? t.substring(0, 500) : t;
        tts.stop();
        tts.speak(preview, TextToSpeech.QUEUE_FLUSH, null, "preview");
        statusText.setText("正在試聽前 500 字……");
    }

    private List<String> splitText(String text, int max) {
        List<String> result = new ArrayList<>();
        String remaining = text.trim();
        while (remaining.length() > max) {
            int cut = max;
            int best = -1;
            String head = remaining.substring(0, max);
            for (String sep : new String[]{"。","！","？","；","\n","，"}) {
                int p = head.lastIndexOf(sep);
                if (p > max * 0.55 && p > best) best = p + 1;
            }
            if (best > 0) cut = best;
            result.add(remaining.substring(0, cut).trim());
            remaining = remaining.substring(cut).trim();
        }
        if (!remaining.isEmpty()) result.add(remaining);
        return result;
    }

    private void createMergedAudio() {
        String t = getTextOrWarn();
        if (t == null) return;

        applySettings();
        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (dir == null) {
            statusText.setText("無法建立音檔資料夾。");
            return;
        }
        if (!dir.exists()) dir.mkdirs();

        List<String> parts = splitText(t, 3000);
        createButton.setEnabled(false);
        statusText.setText("準備產生，共 " + parts.size() + " 段……");

        List<File> tempFiles = new ArrayList<>();
        synthesizePart(parts, 0, dir, tempFiles);
    }

    private void synthesizePart(List<String> parts, int index, File dir, List<File> tempFiles) {
        if (index >= parts.size()) {
            try {
                File merged = new File(dir, "AI完整語音_" + System.currentTimeMillis() + ".wav");
                mergeWavFiles(tempFiles, merged);

                for (File f : tempFiles) {
                    if (f.exists()) f.delete();
                }

                currentAudioFile = merged;
                createButton.setEnabled(true);
                statusText.setText("完成！已合併成單一音檔：\n" + merged.getName());
                loadIntoPlayer(merged);
                refreshFileList();
                addRecentText(inputText.getText().toString());
            } catch (Exception e) {
                createButton.setEnabled(true);
                statusText.setText("合併失敗：" + e.getMessage());
            }
            return;
        }

        File out = new File(dir, "tmp_" + System.currentTimeMillis() + "_" + index + ".wav");
        String utteranceId = "part_" + index + "_" + System.currentTimeMillis();

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            public void onStart(String id) {
                runOnUiThread(() -> statusText.setText("正在產生第 " + (index + 1) + " / " + parts.size() + " 段……"));
            }
            public void onDone(String id) {
                tempFiles.add(out);
                runOnUiThread(() -> synthesizePart(parts, index + 1, dir, tempFiles));
            }
            public void onError(String id) {
                runOnUiThread(() -> {
                    createButton.setEnabled(true);
                    statusText.setText("第 " + (index + 1) + " 段產生失敗。");
                });
            }
        });

        int r = tts.synthesizeToFile(parts.get(index), null, out, utteranceId);
        if (r == TextToSpeech.ERROR) {
            createButton.setEnabled(true);
            statusText.setText("無法開始產生音檔。");
        }
    }

    private static class WavInfo {
        byte[] fmt;
        long dataOffset;
        long dataSize;
    }

    private WavInfo parseWav(File file) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            if (raf.length() < 12) throw new IOException("音檔太短，不是有效 WAV");

            byte[] id = new byte[4];
            raf.readFully(id);
            if (!"RIFF".equals(new String(id, java.nio.charset.StandardCharsets.US_ASCII))) {
                throw new IOException("此手機 TTS 引擎輸出不是 RIFF WAV");
            }
            readIntLE(raf); // RIFF size
            raf.readFully(id);
            if (!"WAVE".equals(new String(id, java.nio.charset.StandardCharsets.US_ASCII))) {
                throw new IOException("此音檔不是 WAVE 格式");
            }

            WavInfo info = new WavInfo();

            while (raf.getFilePointer() + 8 <= raf.length()) {
                raf.readFully(id);
                String chunkId = new String(id, java.nio.charset.StandardCharsets.US_ASCII);
                long chunkSize = Integer.toUnsignedLong(readIntLE(raf));
                long chunkDataPos = raf.getFilePointer();

                if ("fmt ".equals(chunkId)) {
                    if (chunkSize > 1024 * 1024) throw new IOException("WAV fmt 區塊異常");
                    info.fmt = new byte[(int)chunkSize];
                    raf.readFully(info.fmt);
                } else if ("data".equals(chunkId)) {
                    info.dataOffset = chunkDataPos;
                    info.dataSize = Math.min(chunkSize, raf.length() - chunkDataPos);
                    raf.seek(chunkDataPos + chunkSize);
                } else {
                    raf.seek(chunkDataPos + chunkSize);
                }

                if ((chunkSize & 1L) == 1L && raf.getFilePointer() < raf.length()) {
                    raf.seek(raf.getFilePointer() + 1);
                }

                if (info.fmt != null && info.dataSize > 0) break;
            }

            if (info.fmt == null || info.dataSize <= 0) {
                throw new IOException("找不到 WAV 的 fmt 或 data 區塊");
            }
            return info;
        }
    }

    private void mergeWavFiles(List<File> files, File out) throws IOException {
        if (files.isEmpty()) throw new IOException("沒有可合併的音檔");

        List<WavInfo> infos = new ArrayList<>();
        WavInfo first = null;
        long totalData = 0;

        for (File f : files) {
            WavInfo info = parseWav(f);
            if (first == null) {
                first = info;
            } else if (!Arrays.equals(first.fmt, info.fmt)) {
                throw new IOException("各分段 WAV 音訊格式不一致");
            }
            infos.add(info);
            totalData += info.dataSize;
        }

        if (totalData > 0xFFFFFFFFL - 36) {
            throw new IOException("合併後音檔過大，超過標準 WAV 上限");
        }

        try (FileOutputStream fos = new FileOutputStream(out)) {
            fos.write("RIFF".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            writeIntLE(fos, (int)(4 + (8 + first.fmt.length) + (8 + totalData)));
            fos.write("WAVE".getBytes(java.nio.charset.StandardCharsets.US_ASCII));

            fos.write("fmt ".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            writeIntLE(fos, first.fmt.length);
            fos.write(first.fmt);
            if ((first.fmt.length & 1) == 1) fos.write(0);

            fos.write("data".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            writeIntLE(fos, (int)totalData);

            byte[] buffer = new byte[64 * 1024];
            for (int i = 0; i < files.size(); i++) {
                File f = files.get(i);
                WavInfo info = infos.get(i);
                try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
                    raf.seek(info.dataOffset);
                    long remain = info.dataSize;
                    while (remain > 0) {
                        int n = raf.read(buffer, 0, (int)Math.min(buffer.length, remain));
                        if (n < 0) throw new EOFException("WAV data 區塊不完整");
                        fos.write(buffer, 0, n);
                        remain -= n;
                    }
                }
            }
        }
    }

    private int readIntLE(RandomAccessFile raf) throws IOException {
        int b0 = raf.read();
        int b1 = raf.read();
        int b2 = raf.read();
        int b3 = raf.read();
        if ((b0 | b1 | b2 | b3) < 0) throw new EOFException();
        return (b0) | (b1 << 8) | (b2 << 16) | (b3 << 24);
    }

    private void writeIntLE(OutputStream out, int value) throws IOException {
        out.write(value & 0xFF);
        out.write((value >>> 8) & 0xFF);
        out.write((value >>> 16) & 0xFF);
        out.write((value >>> 24) & 0xFF);
    }

    private void loadIntoPlayer(File f) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(f.getAbsolutePath());
            mediaPlayer.prepare();

            currentAudioFile = f;
            playButton.setEnabled(true);
            pauseButton.setEnabled(true);
            shareButton.setEnabled(true);

            int dur = mediaPlayer.getDuration();
            playbackSeek.setProgress(0);
            timeText.setText("00:00 / " + formatTime(dur));

            mediaPlayer.setOnCompletionListener(mp -> {
                playbackSeek.setProgress(1000);
                timeText.setText(formatTime(mp.getDuration()) + " / " + formatTime(mp.getDuration()));
            });
        } catch (Exception e) {
            statusText.setText("播放器載入失敗：" + e.getMessage());
        }
    }

    private void playCurrent() {
        if (mediaPlayer == null && currentAudioFile != null) loadIntoPlayer(currentAudioFile);
        if (mediaPlayer != null) {
            mediaPlayer.start();
            handler.removeCallbacks(progressUpdater);
            handler.post(progressUpdater);
            statusText.setText("正在播放：" + (currentAudioFile != null ? currentAudioFile.getName() : ""));
        }
    }

    private void pauseCurrent() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            handler.removeCallbacks(progressUpdater);
            statusText.setText("已暫停。");
        }
    }

    private String formatTime(int ms) {
        int totalSec = Math.max(0, ms / 1000);
        int min = totalSec / 60;
        int sec = totalSec % 60;
        return String.format(Locale.TAIWAN, "%02d:%02d", min, sec);
    }

    private void saveArticle() {
        String t = getTextOrWarn();
        if (t == null) return;

        EditText nameInput = new EditText(this);
        nameInput.setHint("文章名稱");

        new AlertDialog.Builder(this)
            .setTitle("保存文章")
            .setView(nameInput)
            .setPositiveButton("保存", (d,w) -> {
                String name = nameInput.getText().toString().trim();
                if (name.isEmpty()) name = "未命名文章";
                saveNamedArticle(name, t);
                Toast.makeText(this, "文章已保存", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("取消", null)
            .show();
    }

    private void saveNamedArticle(String name, String text) {
        SharedPreferences articlePrefs = getSharedPreferences("aitts_articles", MODE_PRIVATE);
        Set<String> names = new LinkedHashSet<>(articlePrefs.getStringSet("names", new LinkedHashSet<>()));
        names.add(name);
        articlePrefs.edit()
                .putStringSet("names", names)
                .putString("article_" + name, text)
                .apply();
    }

    private void addRecentText(String text) {
        SharedPreferences recent = getSharedPreferences("aitts_recent", MODE_PRIVATE);
        List<String> list = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            String v = recent.getString("r" + i, null);
            if (v != null && !v.equals(text)) list.add(v);
        }
        list.add(0, text);
        if (list.size() > 10) list = list.subList(0, 10);

        SharedPreferences.Editor e = recent.edit().clear();
        for (int i = 0; i < list.size(); i++) e.putString("r" + i, list.get(i));
        e.apply();
    }

    private void showRecentTexts() {
        SharedPreferences recent = getSharedPreferences("aitts_recent", MODE_PRIVATE);
        List<String> values = new ArrayList<>();
        List<String> labels = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            String v = recent.getString("r" + i, null);
            if (v != null) {
                values.add(v);
                labels.add(v.length() > 40 ? v.substring(0, 40) + "…" : v);
            }
        }

        if (values.isEmpty()) {
            Toast.makeText(this, "尚無最近使用文字", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
            .setTitle("最近使用文字")
            .setItems(labels.toArray(new String[0]), (d, which) -> {
                inputText.setText(values.get(which));
                inputText.setSelection(inputText.length());
            })
            .setNegativeButton("關閉", null)
            .show();
    }

    private void showSavedArticles() {
        SharedPreferences articlePrefs = getSharedPreferences("aitts_articles", MODE_PRIVATE);
        Set<String> saved = articlePrefs.getStringSet("names", new LinkedHashSet<>());

        if (saved == null || saved.isEmpty()) {
            Toast.makeText(this, "尚無已保存文章", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> names = new ArrayList<>(saved);
        Collections.sort(names);

        new AlertDialog.Builder(this)
            .setTitle("已保存文章")
            .setItems(names.toArray(new String[0]), (d, which) -> {
                String text = articlePrefs.getString("article_" + names.get(which), "");
                inputText.setText(text);
                inputText.setSelection(inputText.length());
            })
            .setNeutralButton("刪除文章", (d, w) -> showDeleteSavedArticles())
            .setNegativeButton("關閉", null)
            .show();
    }

    private void showDeleteSavedArticles() {
        SharedPreferences articlePrefs = getSharedPreferences("aitts_articles", MODE_PRIVATE);
        Set<String> saved = articlePrefs.getStringSet("names", new LinkedHashSet<>());
        if (saved == null || saved.isEmpty()) return;

        List<String> names = new ArrayList<>(saved);
        Collections.sort(names);

        new AlertDialog.Builder(this)
            .setTitle("選擇要刪除的文章")
            .setItems(names.toArray(new String[0]), (d, which) -> {
                String name = names.get(which);
                Set<String> newNames = new LinkedHashSet<>(saved);
                newNames.remove(name);
                articlePrefs.edit()
                    .putStringSet("names", newNames)
                    .remove("article_" + name)
                    .apply();
                Toast.makeText(this, "已刪除：" + name, Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("取消", null)
            .show();
    }

    private void refreshFileList() {
        fileList.removeAllViews();
        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);

        if (dir == null || !dir.exists()) {
            addEmpty();
            return;
        }

        File[] arr = dir.listFiles((d, name) ->
                name.toLowerCase(Locale.ROOT).endsWith(".wav") && !name.startsWith("tmp_"));

        if (arr == null || arr.length == 0) {
            addEmpty();
            return;
        }

        Arrays.sort(arr, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));

        for (File f : arr) addFileRow(f);
    }

    private void addEmpty() {
        TextView tv = new TextView(this);
        tv.setText("尚無音檔。");
        fileList.addView(tv);
    }

    private void addFileRow(File f) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, 12, 0, 12);

        TextView name = new TextView(this);
        name.setText(f.getName());
        name.setTextSize(15);
        box.addView(name);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button play = new Button(this); play.setText("播放");
        Button share = new Button(this); share.setText("分享");
        Button rename = new Button(this); rename.setText("改名");
        Button del = new Button(this); del.setText("刪除");

        for (Button b : new Button[]{play,share,rename,del}) {
            row.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }

        play.setOnClickListener(v -> {
            loadIntoPlayer(f);
            playCurrent();
        });

        share.setOnClickListener(v -> shareFile(f));
        rename.setOnClickListener(v -> renameFile(f));
        del.setOnClickListener(v -> deleteFile(f));

        box.addView(row);
        fileList.addView(box);
    }

    private void shareFile(File f) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName()+".fileprovider", f);

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(i, "分享音檔"));
    }

    private void renameFile(File f) {
        EditText input = new EditText(this);
        input.setText(f.getName().replace(".wav",""));

        new AlertDialog.Builder(this)
            .setTitle("重新命名")
            .setView(input)
            .setPositiveButton("確定", (d,w) -> {
                String n = input.getText().toString().trim();
                if (!n.isEmpty()) {
                    File nf = new File(f.getParentFile(), n + ".wav");
                    if (f.renameTo(nf)) {
                        if (currentAudioFile != null && currentAudioFile.equals(f)) currentAudioFile = nf;
                        refreshFileList();
                    } else {
                        Toast.makeText(this,"重新命名失敗",Toast.LENGTH_SHORT).show();
                    }
                }
            })
            .setNegativeButton("取消", null)
            .show();
    }

    private void deleteFile(File f) {
        new AlertDialog.Builder(this)
            .setTitle("刪除音檔")
            .setMessage("確定刪除 " + f.getName() + "？")
            .setPositiveButton("刪除", (d,w) -> {
                if (currentAudioFile != null && currentAudioFile.equals(f)) {
                    if (mediaPlayer != null) {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        mediaPlayer = null;
                    }
                    currentAudioFile = null;
                    playButton.setEnabled(false);
                    pauseButton.setEnabled(false);
                    shareButton.setEnabled(false);
                }

                if (f.delete()) refreshFileList();
                else Toast.makeText(this,"刪除失敗",Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("取消", null)
            .show();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(progressUpdater);

        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }

        if (mediaPlayer != null) {
            mediaPlayer.release();
        }

        super.onDestroy();
    }
}
