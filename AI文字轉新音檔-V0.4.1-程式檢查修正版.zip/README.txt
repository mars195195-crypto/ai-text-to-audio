AI文字轉新音檔 V0.4 免費測試版
================================

V0.4 新增
- 長文自動分段
- 多段 WAV 自動合併成一個完整音檔
- 播放進度條
- 播放時間顯示
- 暫停 / 繼續播放
- 文章自動暫存
- 保存文章
- 最近使用文字
- 已產生音檔清單
- 播放 / 分享 / 改名 / 刪除

免費測試版維持
- 不收費
- 不扣點
- 不登入
- 不需要 API Key
- 不需要伺服器
- 使用 Android 手機內建 TTS

重要技術說明
1. 多段自動合併目前以標準 WAV PCM 標頭進行合併。
2. 大多數 Google TTS / Android 標準 TTS 產生的 WAV 可以正常合併。
3. 如果某支手機的 TTS 引擎輸出不是標準 44-byte PCM WAV，系統可能顯示「WAV 格式不一致」。
4. 若未來要做到所有手機都穩定合併，建議 V0.4 改用 Android MediaCodec 或 FFmpeg 做轉碼合併。
5. 暫停後按「播放」即可繼續。

文章保存
- 最後輸入文字會自動暫存在 SharedPreferences。
- 「保存文章」可以用名稱保存內容。
- 「最近文字」會保存最近 10 筆成功產生音檔的文字。

建置 APK
1. Android Studio 開啟本資料夾
2. 等待 Gradle Sync
3. Build → Build APK(s)
4. APK 通常產生於：
   app/build/outputs/apk/debug/app-debug.apk

Android
- minSdk 26
- targetSdk 35
- Java 17
- versionName 0.4
- package: global.009.aitts


V0.4 新增：GitHub Actions 自動產生 APK，請看 README-GITHUB.txt。
