package global.a009.aitts;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;


import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {

    private TextToSpeech tts;
    private EditText inputText;
    private Spinner voiceFilterSpinner, voiceSpinner, styleSpinner;
    private SeekBar rateSeek, pitchSeek, playbackSeek;
    private TextView statusText, charCount, timeText;
    private LinearLayout audioList;

    private Button previewPlayButton, previewPauseButton, previewResumeButton, previewStopButton;
    private Button createButton, playButton, pauseButton, resumeButton;
    private Button saveArticleButton, savedArticlesButton, recentButton;

    private final List<Voice> voices = new ArrayList<>();
    private final List<Voice> filteredVoices = new ArrayList<>();

    private MediaPlayer player;
    private MediaPlayer previewPlayer;
    private File previewFile;
    private File currentFile;
    private Uri savedAudioUri;
    private SharedPreferences prefs;
    private String previewTextCache = "";
    private boolean ttsReady = false;

    private static final int CHUNK_SIZE = 2500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("aitts_v018", MODE_PRIVATE);
        setContentView(buildUi());
        initTts();
        refreshAudioList();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root);

        root.addView(text("AI 文字轉新音檔", 28, true));
        root.addView(text("V0.18.3｜標點完全靜音修正版", 14, false));

        inputText = new EditText(this);
        inputText.setHint("把要朗讀的文字貼在這裡……");
        inputText.setGravity(Gravity.TOP);
        inputText.setMinHeight(dp(220));
        inputText.setText(prefs.getString("last_text", ""));
        root.addView(inputText, matchWrap());

        charCount = text(inputText.length() + " 字", 13, false);
        charCount.setGravity(Gravity.END);
        root.addView(charCount);

        inputText.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                charCount.setText(s.length() + " 字");
                prefs.edit().putString("last_text", s.toString()).apply();
            }
            public void afterTextChanged(Editable e) {}
        });

        LinearLayout articleRow1 = horizontal();
        saveArticleButton = button("保存文章");
        savedArticlesButton = button("已保存文章");
        articleRow1.addView(saveArticleButton, weight());
        articleRow1.addView(savedArticlesButton, weight());
        root.addView(articleRow1);

        recentButton = button("最近使用文字");
        root.addView(recentButton, matchWrap());

        root.addView(text("聲音分類", 16, true));
        voiceFilterSpinner = new Spinner(this);
        String[] voiceFilters = {"🇹🇼 全部台灣語音", "👩 台灣女聲", "👨 台灣男聲", "⚪ 未標示"};
        voiceFilterSpinner.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, voiceFilters));
        
        voiceFilterSpinner.setSelection(2);
root.addView(voiceFilterSpinner, matchWrap());

        root.addView(text("可用語音", 16, true));
        voiceSpinner = new Spinner(this);
        root.addView(voiceSpinner, matchWrap());

        Button manageTtsButton = button("⚙ 管理手機台灣語音");
        root.addView(manageTtsButton, matchWrap());

        manageTtsButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent("com.android.settings.TTS_SETTINGS");
                startActivity(intent);
            } catch (Exception e) {
                try {
                    Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
                    startActivity(intent);
                } catch (Exception ignored) {
                    Toast.makeText(
                            this,
                            "請到手機設定 → 文字轉語音輸出，安裝繁體中文（台灣）語音",
                            Toast.LENGTH_LONG
                    ).show();
                }
            }
        });

        voiceFilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                refreshVoiceSpinner();
                refreshFreeProfileSpinner();
            }
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        root.addView(text("免費台灣聲線風格（男／女各 10 組）", 16, true));
        styleSpinner = new Spinner(this);
        refreshFreeProfileSpinner();
        root.addView(styleSpinner, matchWrap());

        root.addView(text("語速", 16, true));
        rateSeek = new SeekBar(this);
        rateSeek.setMax(150);
        rateSeek.setProgress(45);
        root.addView(rateSeek, matchWrap());

        root.addView(text("音調", 16, true));
        pitchSeek = new SeekBar(this);
        pitchSeek.setMax(100);
        pitchSeek.setProgress(50);
        root.addView(pitchSeek, matchWrap());

        styleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyStylePreset(position);
            }
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        root.addView(text("試聽控制", 18, true));

        LinearLayout p1 = horizontal();
        previewPlayButton = button("▶ 試聽");
        previewPauseButton = button("⏸ 暫停");
        p1.addView(previewPlayButton, weight());
        p1.addView(previewPauseButton, weight());
        root.addView(p1);

        LinearLayout p2 = horizontal();
        previewResumeButton = button("▶ 繼續");
        previewStopButton = button("■ 停止");
        p2.addView(previewResumeButton, weight());
        p2.addView(previewStopButton, weight());
        root.addView(p2);

        createButton = button("產生完整音檔＋SRT字幕");
        root.addView(createButton, matchWrap());

        statusText = text("語音引擎初始化中……", 14, false);
        root.addView(statusText);

        root.addView(text("完整音檔播放器", 20, true));
        playbackSeek = new SeekBar(this);
        playbackSeek.setMax(1000);
        root.addView(playbackSeek, matchWrap());

        timeText = text("00:00 / 00:00", 14, false);
        timeText.setGravity(Gravity.CENTER);
        root.addView(timeText);

        LinearLayout playRow = horizontal();
        playButton = button("▶ 播放");
        pauseButton = button("⏸ 暫停");
        playRow.addView(playButton, weight());
        playRow.addView(pauseButton, weight());
        root.addView(playRow);

        resumeButton = button("▶ 繼續播放");
        root.addView(resumeButton, matchWrap());
previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
        previewStopButton.setEnabled(true);

        playButton.setEnabled(false);
        pauseButton.setEnabled(false);
        resumeButton.setEnabled(false);

        root.addView(text("已產生音檔", 20, true));
        audioList = new LinearLayout(this);
        audioList.setOrientation(LinearLayout.VERTICAL);
        root.addView(audioList, matchWrap());

        root.addView(text(
                "※ 免費模式：不登入、不扣點、不需 API Key。優先使用手機內建免費台灣語音；男／女各提供 10 組聲線風格。這些風格由可用的真實台灣基礎聲音搭配語速與音調調整，不會假稱為 20 個獨立神經語音人物。產生語音時同步建立 SRT 字幕。",
                12, false));

        previewPlayButton.setOnClickListener(v -> previewText());
        previewPauseButton.setOnClickListener(v -> pausePreview());
        previewResumeButton.setOnClickListener(v -> resumePreview());
        previewStopButton.setOnClickListener(v -> stopPreview());

        createButton.setOnClickListener(v -> createAudio());
        playButton.setOnClickListener(v -> playAudio());
        pauseButton.setOnClickListener(v -> pauseAudio());
        resumeButton.setOnClickListener(v -> resumeAudio());

        saveArticleButton.setOnClickListener(v -> saveArticle());
        savedArticlesButton.setOnClickListener(v -> showSavedArticles());
        recentButton.setOnClickListener(v -> showRecent());

        playbackSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (player != null) {
                    int dur = player.getDuration();
                    player.seekTo((int)(dur * (seekBar.getProgress() / 1000.0)));
                    updateTime();
                }
            }
        });

        return scroll;
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                statusText.setText("TTS 語音引擎啟動失敗。");
                return;
            }

            int lang = tts.setLanguage(Locale.TAIWAN);
            if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                statusText.setText("手機尚未安裝繁體中文（台灣）語音資料。");
                return;
            }

            ttsReady = true;
            loadVoices();
            statusText.setText("台灣語音引擎已就緒。");
        });
    }

    private void loadVoices() {
        voices.clear();

        Set<Voice> set = tts.getVoices();

        if (set != null) {
            for (Voice v : set) {
                Locale locale = v.getLocale();

                if (locale == null) continue;

                String language = locale.getLanguage();
                String country = locale.getCountry();

                // V0.17：只接受台灣繁體中文 zh-TW。
                boolean taiwanChinese =
                        ("zh".equalsIgnoreCase(language)
                                || "cmn".equalsIgnoreCase(language))
                                && "TW".equalsIgnoreCase(country);

                if (taiwanChinese) {
                    voices.add(v);
                }
            }
        }

        Collections.sort(
                voices,
                Comparator.comparing(Voice::getName)
        );

        refreshVoiceSpinner();
    }

    private String detectGender(Voice voice) {
        if (voice == null) return "unknown";
        String n = voice.getName() == null
                ? ""
                : voice.getName().toLowerCase(Locale.ROOT);

        // Google / Android 台灣國語常見語音代碼：
        // ctc = 女聲
        // ctd = 男聲
        // cte = 男聲
        // zh-TW-language = 系統預設女聲
        if (n.contains("cmn-tw-x-ctc")) return "female";
        if (n.contains("cmn-tw-x-ctd")) return "male";
        if (n.contains("cmn-tw-x-cte")) return "male";
        if (n.equals("zh-tw-language")) return "female";

        // 其他 TTS 引擎仍保留一般名稱判斷。
        String[] femaleHints = {
                "female", "woman", "girl", "fem",
                "hsiaochen", "hsiaoyu", "yating",
                "tingting", "huihui", "mei", "lili"
        };

        String[] maleHints = {
                "male", "man", "boy",
                "yunjhe", "yunxi", "yunyang",
                "yunfeng", "yunhao", "kangkang", "zhiyu"
        };

        for (String h : femaleHints) {
            if (n.contains(h)) return "female";
        }

        for (String h : maleHints) {
            if (n.contains(h)) return "male";
        }

        return "unknown";
    }

    private String genderIcon(Voice voice) {
        String g = detectGender(voice);
        String n = voice == null || voice.getName() == null
                ? ""
                : voice.getName().toLowerCase(Locale.ROOT);

        if (n.contains("cmn-tw-x-ctc")) return "👩 台灣女聲 1";
        if (n.contains("cmn-tw-x-ctd")) return "👨 台灣男聲 1";
        if (n.contains("cmn-tw-x-cte")) return "👨 台灣男聲 2";
        if (n.equals("zh-tw-language")) return "👩 台灣系統女聲";

        if ("female".equals(g)) return "👩 台灣女聲";
        if ("male".equals(g)) return "👨 台灣男聲";
        return "⚪ 未標示";
    }

    private String voiceSourceLabel(Voice voice) {
        if (voice == null || voice.getName() == null) return "";

        String n = voice.getName().toLowerCase(Locale.ROOT);

        if (n.endsWith("-local")) return "離線";
        if (n.endsWith("-network")) return "網路";
        if (n.equals("zh-tw-language")) return "系統";
        return "";
    }

    private String localeLabel(Locale locale) {
        if (locale == null) return "繁體中文（台灣）";

        String language = locale.getLanguage();
        String country = locale.getCountry();

        boolean taiwanChinese =
                ("zh".equalsIgnoreCase(language)
                        || "cmn".equalsIgnoreCase(language))
                        && "TW".equalsIgnoreCase(country);

        return taiwanChinese
                ? "繁體中文（台灣）"
                : locale.toLanguageTag();
    }

    private int preferredVoiceIndex() {
        // 優先順序：
        // 1. 台灣男聲 1 網路版（ctd-network）
        // 2. 台灣男聲 1 離線版（ctd-local）
        // 3. 台灣男聲 2 網路版（cte-network）
        // 4. 台灣男聲 2 離線版（cte-local）
        // 5. 其他可用台灣男聲
        String[] priority = {
                "cmn-tw-x-ctd-network",
                "cmn-tw-x-ctd-local",
                "cmn-tw-x-cte-network",
                "cmn-tw-x-cte-local"
        };

        for (String key : priority) {
            for (int i = 0; i < filteredVoices.size(); i++) {
                Voice v = filteredVoices.get(i);
                if (v != null && v.getName() != null
                        && v.getName().toLowerCase(Locale.ROOT).contains(key)) {
                    return i;
                }
            }
        }

        for (int i = 0; i < filteredVoices.size(); i++) {
            if ("male".equals(detectGender(filteredVoices.get(i)))) {
                return i;
            }
        }

        return filteredVoices.isEmpty() ? -1 : 0;
    }

    private void refreshVoiceSpinner() {
        if (voiceSpinner == null || voiceFilterSpinner == null) return;

        filteredVoices.clear();
        int mode = voiceFilterSpinner.getSelectedItemPosition();

        for (Voice v : voices) {
            String gender = detectGender(v);

            boolean include =
                    mode == 0 ||
                    (mode == 1 && "female".equals(gender)) ||
                    (mode == 2 && "male".equals(gender)) ||
                    (mode == 3 && "unknown".equals(gender));

            if (include) {
                filteredVoices.add(v);
            }
        }

        List<String> labels = new ArrayList<>();

        if (filteredVoices.isEmpty()) {
            if (voices.isEmpty()) {
                labels.add("⚠ 尚未安裝台灣繁體中文語音");
            } else if (mode == 2) {
                labels.add("⚠ 尚未偵測到台灣男聲");
            } else if (mode == 1) {
                labels.add("⚠ 尚未偵測到台灣女聲");
            } else if (mode == 3) {
                labels.add("目前沒有未標示的台灣語音");
            } else {
                labels.add("⚠ 找不到台灣繁體中文語音");
            }
        } else {
            for (Voice v : filteredVoices) {
                String source = voiceSourceLabel(v);
                labels.add(
                        genderIcon(v)
                                + "｜繁體中文（台灣）"
                                + (source.isEmpty() ? "" : "｜" + source)
                                + "｜"
                                + v.getName()
                );
            }
        }

        voiceSpinner.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
        ));

        if (!filteredVoices.isEmpty()) {
            int preferred = preferredVoiceIndex();
            if (preferred >= 0 && preferred < filteredVoices.size()) {
                voiceSpinner.setSelection(preferred);
            }
        }
    }

    private void refreshFreeProfileSpinner() {
        if (styleSpinner == null) return;

        int mode = voiceFilterSpinner == null
                ? 2
                : voiceFilterSpinner.getSelectedItemPosition();

        String[] maleProfiles = {
                "👨 男聲 01｜自然沉穩",
                "👨 男聲 02｜溫暖親切",
                "👨 男聲 03｜專業旁白",
                "👨 男聲 04｜新聞播報",
                "👨 男聲 05｜成熟磁性",
                "👨 男聲 06｜商務簡報",
                "👨 男聲 07｜活力推廣",
                "👨 男聲 08｜故事敘述",
                "👨 男聲 09｜深沉慢語",
                "👨 男聲 10｜清晰自然"
        };

        String[] femaleProfiles = {
                "👩 女聲 01｜自然親切",
                "👩 女聲 02｜溫柔療癒",
                "👩 女聲 03｜專業旁白",
                "👩 女聲 04｜新聞播報",
                "👩 女聲 05｜年輕活力",
                "👩 女聲 06｜商務簡報",
                "👩 女聲 07｜故事敘述",
                "👩 女聲 08｜柔和慢語",
                "👩 女聲 09｜清晰自然",
                "👩 女聲 10｜溫暖推廣"
        };

        String[] genericProfiles = {
                "01｜自然",
                "02｜溫暖",
                "03｜專業旁白",
                "04｜新聞播報",
                "05｜成熟",
                "06｜商務",
                "07｜活力",
                "08｜故事",
                "09｜慢語",
                "10｜清晰"
        };

        String[] data;
        if (mode == 2) {
            data = maleProfiles;
        } else if (mode == 1) {
            data = femaleProfiles;
        } else {
            data = genericProfiles;
        }

        styleSpinner.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                data
        ));
    }

    private int findVoiceIndexByKey(String... keys) {
        for (String key : keys) {
            for (int i = 0; i < filteredVoices.size(); i++) {
                Voice v = filteredVoices.get(i);
                if (v == null || v.getName() == null) continue;

                String n = v.getName().toLowerCase(Locale.ROOT);
                if (n.contains(key.toLowerCase(Locale.ROOT))) {
                    return i;
                }
            }
        }
        return -1;
    }

    private void selectBaseVoiceForFreeProfile(int profile) {
        if (filteredVoices.isEmpty()) return;

        int mode = voiceFilterSpinner == null
                ? 0
                : voiceFilterSpinner.getSelectedItemPosition();

        int index = -1;

        if (mode == 2) {
            // 男聲：ctd / cte 兩組真正免費台灣基礎聲線交錯使用。
            if (profile % 2 == 0) {
                index = findVoiceIndexByKey(
                        "cmn-tw-x-ctd-network",
                        "cmn-tw-x-ctd-local",
                        "cmn-tw-x-ctd"
                );
            } else {
                index = findVoiceIndexByKey(
                        "cmn-tw-x-cte-network",
                        "cmn-tw-x-cte-local",
                        "cmn-tw-x-cte"
                );
            }
        } else if (mode == 1) {
            // 女聲：ctc / 系統 zh-TW 兩組免費台灣基礎聲線交錯使用。
            if (profile % 2 == 0) {
                index = findVoiceIndexByKey(
                        "cmn-tw-x-ctc-network",
                        "cmn-tw-x-ctc-local",
                        "cmn-tw-x-ctc"
                );
            } else {
                index = findVoiceIndexByKey(
                        "zh-tw-language",
                        "cmn-tw-x-ctc-network",
                        "cmn-tw-x-ctc-local",
                        "cmn-tw-x-ctc"
                );
            }
        }

        if (index < 0) {
            index = preferredVoiceIndex();
        }

        if (index >= 0 && index < filteredVoices.size()) {
            voiceSpinner.setSelection(index);
        }
    }

    private void applyStylePreset(int mode) {
        // 這 10 組是免費台灣系統聲音 + 語速 / 音調的聲線風格組合。
        // 不把調音後的風格假稱為 10 個獨立神經語音模型。
        int filterMode = voiceFilterSpinner == null
                ? 0
                : voiceFilterSpinner.getSelectedItemPosition();

        selectBaseVoiceForFreeProfile(mode);

        if (filterMode == 2) {
            // 男聲：整體音調稍低，保留台灣男聲原本聲線。
            int[][] male = {
                    {45, 42}, // 自然沉穩
                    {43, 46}, // 溫暖親切
                    {47, 40}, // 專業旁白
                    {52, 44}, // 新聞播報
                    {39, 36}, // 成熟磁性
                    {48, 43}, // 商務簡報
                    {61, 47}, // 活力推廣
                    {41, 45}, // 故事敘述
                    {33, 34}, // 深沉慢語
                    {50, 45}  // 清晰自然
            };
            int i = Math.max(0, Math.min(mode, male.length - 1));
            rateSeek.setProgress(male[i][0]);
            pitchSeek.setProgress(male[i][1]);
            return;
        }

        if (filterMode == 1) {
            // 女聲：保留自然女聲，不用過高音調製造假聲。
            int[][] female = {
                    {45, 53}, // 自然親切
                    {34, 51}, // 溫柔療癒
                    {47, 50}, // 專業旁白
                    {53, 52}, // 新聞播報
                    {59, 58}, // 年輕活力
                    {48, 51}, // 商務簡報
                    {41, 55}, // 故事敘述
                    {32, 49}, // 柔和慢語
                    {50, 52}, // 清晰自然
                    {56, 56}  // 溫暖推廣
            };
            int i = Math.max(0, Math.min(mode, female.length - 1));
            rateSeek.setProgress(female[i][0]);
            pitchSeek.setProgress(female[i][1]);
            return;
        }

        int[][] generic = {
                {45, 50}, {43, 53}, {47, 48}, {52, 50}, {40, 45},
                {48, 50}, {60, 55}, {41, 52}, {33, 44}, {50, 50}
        };
        int i = Math.max(0, Math.min(mode, generic.length - 1));
        rateSeek.setProgress(generic[i][0]);
        pitchSeek.setProgress(generic[i][1]);
    }

    private String naturalizeText(String input) {
        if (input == null) return "";
        String t = input.trim();

        t = t.replace("\r\n", "\n");
        t = t.replace('\r', '\n');

        // V0.18.3：空白行只代表停頓，絕對不要自動補「。」。
        // 舊版把 \n\n 轉成「。\n」，若原文剛好是「？\n\n」或「！\n\n」，
        // 就會變成「？。」「！。」；分段後那個額外的「。」可能被部分 TTS 唸成「點」。
        t = t.replaceAll("\\n{2,}", "\n");

        // 一般單一換行才轉成逗號；若前面本來已有句末標點，就保留換行，不再補任何標點。
        t = t.replaceAll("(?<![。！？!?；;，,])\\n", "，");

        t = t.replaceAll("，{2,}", "，");
        t = t.replaceAll("。{2,}", "。");
        t = t.replaceAll("！{2,}", "！");
        t = t.replaceAll("？{2,}", "？");

        return t;
    }

    /**
     * 只處理送進 TTS 引擎的朗讀文字。
     * 畫面原文與 SRT 字幕完全不改。
     *
     * 重要：不要再把問號／驚嘆號改成逗號或句號。
     * 某些 Android 台灣 TTS 會把任何替代標點仍然朗讀成「點」。
     * 這裡直接把問號／驚嘆號轉成換行停頓，讓 TTS 完全收不到該標點字元。
     */
    private String prepareTextForTts(String text) {
        if (text == null) return "";

        String t = text;

        // 中文／英文問號、驚嘆號與常見 Unicode 變體：全部移出朗讀文字。
        t = t.replaceAll("[？?！!﹖﹗⁇‼❓❔❗❕]+", "\n");

        // 句號也不直接交給 TTS，避免部分引擎把句點類符號唸成「點」。
        // ASCII 小數點若夾在兩個數字中（例如 3.14）則保留。
        t = t.replaceAll("[。．]+", "\n");
        t = t.replaceAll("(?<!\\d)\\.(?!\\d)", "\n");

        // 防止任何「只有標點、沒有文字」的片段被送進 TTS。
        t = t.replaceAll("(?m)^[\\p{Punct}，。！？；：、…．\\s]+$", "");

        // 清掉換行前後多餘空白，避免某些 TTS 把空白異常處理。
        t = t.replaceAll("[\\t\\f\\r ]+", " ");
        t = t.replaceAll(" *\n+ *", "\n");
        t = t.replaceAll("\n{2,}", "\n");

        return t.trim();
    }

    private void applyTtsSettings() {
        tts.setSpeechRate(0.5f + rateSeek.getProgress() / 100f);
        tts.setPitch(0.5f + pitchSeek.getProgress() / 100f);

        if (!filteredVoices.isEmpty()) {
            int pos = voiceSpinner.getSelectedItemPosition();

            if (pos >= 0 && pos < filteredVoices.size()) {
                tts.setVoice(filteredVoices.get(pos));
                return;
            }
        }

        if (!voices.isEmpty()) {
            tts.setVoice(voices.get(0));
            return;
        }

        // 沒有台灣語音時只設定 Locale.TAIWAN，不偷偷切到其他中文地區。
        tts.setLanguage(Locale.TAIWAN);
    }

    private String getTextOrWarn() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "請先輸入文字", Toast.LENGTH_SHORT).show();
            return null;
        }
        return text;
    }

    private void previewText() {
        String text = getTextOrWarn();
        if (text == null) return;

        applyTtsSettings();
        stopPreviewInternal();

        String naturalText = naturalizeText(text);
        previewTextCache = naturalText.length() > 500
                ? naturalText.substring(0, 500)
                : naturalText;

        File dir = getCacheDir();
        previewFile = new File(dir, "preview_" + System.currentTimeMillis() + ".wav");

        String id = "preview_file_" + System.currentTimeMillis();

        previewPlayButton.setEnabled(false);
        previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
        previewStopButton.setEnabled(true);

        statusText.setText("正在準備試聽音檔……");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}

            @Override public void onDone(String utteranceId) {
                runOnUiThread(() -> {
                    try {
                        if (previewPlayer != null) {
                            previewPlayer.release();
                        }

                        previewPlayer = new MediaPlayer();
                        previewPlayer.setDataSource(previewFile.getAbsolutePath());
                        previewPlayer.prepare();

                        previewPlayer.setOnCompletionListener(mp -> {
                            statusText.setText("試聽完成。");
                            previewPlayButton.setEnabled(true);
                            previewPauseButton.setEnabled(false);
                            previewResumeButton.setEnabled(false);
                        });

                        previewPlayer.start();

                        previewPlayButton.setEnabled(false);
                        previewPauseButton.setEnabled(true);
                        previewResumeButton.setEnabled(false);

                        statusText.setText("正在試聽……");

                    } catch (Exception e) {
                        previewPlayButton.setEnabled(true);
                        previewPauseButton.setEnabled(false);
                        previewResumeButton.setEnabled(false);
                        statusText.setText("試聽播放器載入失敗：" + e.getMessage());
                    }
                });
            }

            @Override public void onError(String utteranceId) {
                runOnUiThread(() -> {
                    previewPlayButton.setEnabled(true);
                    previewPauseButton.setEnabled(false);
                    previewResumeButton.setEnabled(false);
                    statusText.setText("試聽音檔產生失敗。");
                });
            }
        });

        int result = tts.synthesizeToFile(
                prepareTextForTts(previewTextCache),
                null,
                previewFile,
                id
        );

        if (result == TextToSpeech.ERROR) {
            previewPlayButton.setEnabled(true);
            previewPauseButton.setEnabled(false);
            previewResumeButton.setEnabled(false);
            statusText.setText("無法開始準備試聽音檔。");
        }
    }

    private void pausePreview() {
        if (previewPlayer != null && previewPlayer.isPlaying()) {
            previewPlayer.pause();
            previewPauseButton.setEnabled(false);
            previewResumeButton.setEnabled(true);
            statusText.setText("試聽已暫停。");
        }
    }

    private void resumePreview() {
        if (previewPlayer != null && !previewPlayer.isPlaying()) {
            try {
                previewPlayer.start();
                previewPauseButton.setEnabled(true);
                previewResumeButton.setEnabled(false);
                statusText.setText("從暫停位置繼續試聽……");
            } catch (Exception e) {
                statusText.setText("無法繼續試聽：" + e.getMessage());
            }
        } else if (previewPlayer == null) {
            Toast.makeText(this, "請先按試聽", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopPreview() {
        stopPreviewInternal();
        statusText.setText("試聽已停止。");
        previewPlayButton.setEnabled(true);
        previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
    }

    private void stopPreviewInternal() {
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
        }

        if (previewPlayer != null) {
            try {
                if (previewPlayer.isPlaying()) {
                    previewPlayer.stop();
                }
            } catch (Exception ignored) {}

            try {
                previewPlayer.release();
            } catch (Exception ignored) {}

            previewPlayer = null;
        }

        if (previewFile != null && previewFile.exists()) {
            try { previewFile.delete(); } catch (Exception ignored) {}
        }

        previewFile = null;
    }

    private List<String> splitText(String text, int maxLen) {
        List<String> parts = new ArrayList<>();
        String remaining = naturalizeText(text);

        while (remaining.length() > maxLen) {
            String head = remaining.substring(0, maxLen);
            int cut = -1;

            for (String sep : new String[]{"。", "！", "？", "；", "，", "\n"}) {
                int pos = head.lastIndexOf(sep);
                if (pos > maxLen * 0.55 && pos > cut) cut = pos + 1;
            }

            if (cut <= 0) cut = maxLen;

            parts.add(remaining.substring(0, cut).trim());
            remaining = remaining.substring(cut).trim();
        }

        if (!remaining.isEmpty()) parts.add(remaining);
        return parts;
    }

    private List<String> splitSubtitleSegments(String text) {
        List<String> result = new ArrayList<>();
        String normalized = naturalizeText(text).trim();
        if (normalized.isEmpty()) return result;

        StringBuilder buffer = new StringBuilder();
        final int preferredMax = 56;
        final int hardMax = 88;

        for (int i = 0; i < normalized.length(); i++) {
            char c = normalized.charAt(i);
            buffer.append(c);

            boolean strongEnd = c == '。' || c == '！' || c == '？' || c == '!' || c == '?';
            boolean softEnd = c == '；' || c == ';' || c == '，' || c == ',' || c == '\n';

            if (strongEnd || (softEnd && buffer.length() >= preferredMax) || buffer.length() >= hardMax) {
                String segment = buffer.toString().trim();
                if (!segment.isEmpty()) result.add(segment);
                buffer.setLength(0);
            }
        }

        String tail = buffer.toString().trim();
        if (!tail.isEmpty()) result.add(tail);

        if (result.isEmpty()) {
            result.addAll(splitText(normalized, hardMax));
        }

        return result;
    }

    private void createAudio() {
        String text = getTextOrWarn();
        if (text == null) return;

        stopPreview();
        applyTtsSettings();

        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (dir == null) {
            statusText.setText("無法建立音檔目錄。");
            return;
        }
        if (!dir.exists()) dir.mkdirs();

        List<String> parts = splitSubtitleSegments(text);
        if (parts.isEmpty()) {
            statusText.setText("沒有可產生的文字內容。");
            return;
        }

        createButton.setEnabled(false);
        statusText.setText("準備同步產生音檔與 SRT 字幕，共 " + parts.size() + " 段……");

        List<File> tempFiles = new ArrayList<>();
        synthesizePart(parts, 0, dir, tempFiles, text);
    }

    private void synthesizePart(
            List<String> parts,
            int index,
            File dir,
            List<File> tempFiles,
            String originalText
    ) {
        if (index >= parts.size()) {
            finishLongAudio(dir, tempFiles, parts, originalText);
            return;
        }

        File out = new File(
                dir,
                "tmp_" + System.currentTimeMillis() + "_" + index + ".wav"
        );

        String id = "chunk_" + index + "_" + System.currentTimeMillis();

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {
                runOnUiThread(() ->
                        statusText.setText(
                                "正在產生第 " + (index + 1) + " / " + parts.size() + " 段音訊與字幕時間……"
                        )
                );
            }

            @Override public void onDone(String utteranceId) {
                tempFiles.add(out);
                runOnUiThread(() ->
                        synthesizePart(parts, index + 1, dir, tempFiles, originalText)
                );
            }

            @Override public void onError(String utteranceId) {
                runOnUiThread(() -> {
                    createButton.setEnabled(true);
                    statusText.setText("第 " + (index + 1) + " 段產生失敗。");
                });
            }
        });

        String speechText = prepareTextForTts(parts.get(index));
        int result = tts.synthesizeToFile(speechText, null, out, id);

        if (result == TextToSpeech.ERROR) {
            createButton.setEnabled(true);
            statusText.setText("無法開始產生第 " + (index + 1) + " 段。");
        }
    }

    private void finishLongAudio(
            File dir,
            List<File> tempFiles,
            List<String> parts,
            String originalText
    ) {
        File merged = null;
        File srt = null;

        try {
            String stem = "AI完整語音_" + System.currentTimeMillis();
            merged = new File(dir, stem + ".wav");
            srt = new File(dir, stem + ".srt");

            mergeWavFiles(tempFiles, merged);
            writeSrtFile(parts, tempFiles, srt);

            for (File f : tempFiles) {
                if (f.exists()) f.delete();
            }

            currentFile = merged;
            savedAudioUri = null;

            createButton.setEnabled(true);
            statusText.setText(
                    "✅ 音檔與字幕同步完成：\n" +
                    merged.getName() + "\n" +
                    srt.getName()
            );

            loadPlayer(merged);
            saveRecent(originalText);
            refreshAudioList();

        } catch (Exception e) {
            createButton.setEnabled(true);

            if (srt != null && srt.exists()) {
                try { srt.delete(); } catch (Exception ignored) {}
            }
            if (merged != null && merged.exists() && merged.length() <= 44) {
                try { merged.delete(); } catch (Exception ignored) {}
            }

            statusText.setText(
                    "音檔／字幕合併失敗：" + safeMessage(e) + "\n" +
                    "已保留 " + tempFiles.size() + " 個分段 WAV 供檢查。"
            );

            refreshAudioList();
        }
    }

    private void writeSrtFile(List<String> parts, List<File> tempFiles, File srtFile) throws IOException {
        if (parts.size() != tempFiles.size()) {
            throw new IOException("字幕段數與音訊段數不一致");
        }

        long cursorMs = 0L;

        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(srtFile), StandardCharsets.UTF_8))) {

            for (int i = 0; i < parts.size(); i++) {
                WavInfo info = parseWav(tempFiles.get(i));
                long durationMs = wavDurationMs(info);
                if (durationMs <= 0) durationMs = 1;

                long startMs = cursorMs;
                long endMs = startMs + durationMs;

                writer.write(String.valueOf(i + 1));
                writer.newLine();
                writer.write(formatSrtTime(startMs) + " --> " + formatSrtTime(endMs));
                writer.newLine();
                writer.write(parts.get(i).trim());
                writer.newLine();
                writer.newLine();

                cursorMs = endMs;
            }
        }
    }

    private long wavDurationMs(WavInfo info) throws IOException {
        int bytesPerSample = info.bitsPerSample / 8;
        long bytesPerSecond = (long) info.sampleRate * info.channels * bytesPerSample;
        if (bytesPerSample <= 0 || bytesPerSecond <= 0) {
            throw new IOException("WAV 時間資訊異常");
        }
        return Math.max(1L, (info.dataSize * 1000L) / bytesPerSecond);
    }

    private String formatSrtTime(long ms) {
        long safe = Math.max(0L, ms);
        long hours = safe / 3600000L;
        safe %= 3600000L;
        long minutes = safe / 60000L;
        safe %= 60000L;
        long seconds = safe / 1000L;
        long millis = safe % 1000L;

        return String.format(
                Locale.US,
                "%02d:%02d:%02d,%03d",
                hours,
                minutes,
                seconds,
                millis
        );
    }

    private File pairedSrtFile(File audioFile) {
        if (audioFile == null) return null;
        String stem = stripAudioExtension(audioFile.getName());
        return new File(audioFile.getParentFile(), stem + ".srt");
    }

    private static class WavInfo {
        byte[] fmt;
        long dataOffset;
        long dataSize;
        int audioFormat;
        int channels;
        int sampleRate;
        int bitsPerSample;
    }

    private int u16le(byte[] b, int off) {
        return (b[off] & 0xff) | ((b[off + 1] & 0xff) << 8);
    }

    private int i32le(byte[] b, int off) {
        return (b[off] & 0xff)
                | ((b[off + 1] & 0xff) << 8)
                | ((b[off + 2] & 0xff) << 16)
                | ((b[off + 3] & 0xff) << 24);
    }

    private WavInfo parseWav(File file) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] id = new byte[4];

            raf.readFully(id);
            if (!"RIFF".equals(new String(id, StandardCharsets.US_ASCII))) {
                throw new IOException("不是 RIFF WAV");
            }

            readIntLE(raf);
            raf.readFully(id);

            if (!"WAVE".equals(new String(id, StandardCharsets.US_ASCII))) {
                throw new IOException("不是 WAVE");
            }

            WavInfo info = new WavInfo();

            while (raf.getFilePointer() + 8 <= raf.length()) {
                raf.readFully(id);
                String chunkId = new String(id, StandardCharsets.US_ASCII);
                long size = Integer.toUnsignedLong(readIntLE(raf));
                long pos = raf.getFilePointer();

                if ("fmt ".equals(chunkId)) {
                    if (size > 1024 * 1024) throw new IOException("fmt 異常");
                    info.fmt = new byte[(int) size];
                    raf.readFully(info.fmt);

                    if (info.fmt.length >= 16) {
                        info.audioFormat = u16le(info.fmt, 0);
                        info.channels = u16le(info.fmt, 2);
                        info.sampleRate = i32le(info.fmt, 4);
                        info.bitsPerSample = u16le(info.fmt, 14);
                    }

                } else if ("data".equals(chunkId)) {
                    info.dataOffset = pos;
                    info.dataSize = Math.min(size, raf.length() - pos);
                    raf.seek(pos + size);

                } else {
                    raf.seek(pos + size);
                }

                if ((size & 1L) == 1L && raf.getFilePointer() < raf.length()) {
                    raf.seek(raf.getFilePointer() + 1);
                }

                if (info.fmt != null && info.dataSize > 0) break;
            }

            if (info.fmt == null || info.dataSize <= 0) {
                throw new IOException("找不到 WAV 音訊資料");
            }

            return info;
        }
    }

    private void mergeWavFiles(List<File> files, File out) throws IOException {
        if (files.isEmpty()) throw new IOException("沒有音檔");

        List<WavInfo> infos = new ArrayList<>();
        WavInfo first = null;
        long total = 0;

        for (File f : files) {
            WavInfo info = parseWav(f);

            if (first == null) {
                first = info;
            } else if (!Arrays.equals(first.fmt, info.fmt)) {
                throw new IOException("WAV 格式不一致");
            }

            infos.add(info);
            total += info.dataSize;
        }

        if (first == null || total <= 0 || total > 0xFFFFFFFFL - 100) {
            throw new IOException("WAV 大小異常");
        }

        try (FileOutputStream fos = new FileOutputStream(out)) {
            fos.write("RIFF".getBytes(StandardCharsets.US_ASCII));

            int fmtPad = (first.fmt.length & 1);
            long riffSize = 4L + 8L + first.fmt.length + fmtPad + 8L + total;

            writeIntLE(fos, (int) riffSize);

            fos.write("WAVE".getBytes(StandardCharsets.US_ASCII));
            fos.write("fmt ".getBytes(StandardCharsets.US_ASCII));
            writeIntLE(fos, first.fmt.length);
            fos.write(first.fmt);

            if (fmtPad == 1) fos.write(0);

            fos.write("data".getBytes(StandardCharsets.US_ASCII));
            writeIntLE(fos, (int) total);

            byte[] buffer = new byte[64 * 1024];

            for (int i = 0; i < files.size(); i++) {
                try (RandomAccessFile raf = new RandomAccessFile(files.get(i), "r")) {
                    WavInfo info = infos.get(i);
                    raf.seek(info.dataOffset);

                    long remain = info.dataSize;

                    while (remain > 0) {
                        int n = raf.read(
                                buffer,
                                0,
                                (int) Math.min(buffer.length, remain)
                        );

                        if (n < 0) throw new EOFException();

                        fos.write(buffer, 0, n);
                        remain -= n;
                    }
                }
            }
        }
    }

    private int readIntLE(RandomAccessFile raf) throws IOException {
        int b0 = raf.read();
        int b1 = raf.read();
        int b2 = raf.read();
        int b3 = raf.read();

        if ((b0 | b1 | b2 | b3) < 0) throw new EOFException();

        return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
    }

    private void writeIntLE(OutputStream out, int value) throws IOException {
        out.write(value & 0xff);
        out.write((value >>> 8) & 0xff);
        out.write((value >>> 16) & 0xff);
        out.write((value >>> 24) & 0xff);
    }

    private void loadPlayer(File file) {
        try {
            if (player != null) player.release();

            player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.prepare();

            currentFile = file;

            playButton.setEnabled(true);
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(true);

            playbackSeek.setProgress(0);
            updateTime();

            player.setOnCompletionListener(mp -> {
                playbackSeek.setProgress(1000);
                updateTime();
                statusText.setText("播放完成。");
            });

        } catch (Exception e) {
            statusText.setText("播放器載入失敗：" + e.getMessage());
        }
    }

    private void playAudio() {
        if (player == null) return;

        if (!player.isPlaying()) {
            player.start();
            statusText.setText("正在播放音檔……");
            updateProgressLoop();
        }
    }

    private void pauseAudio() {
        if (player != null && player.isPlaying()) {
            player.pause();
            statusText.setText("播放已暫停。");
            updateTime();
        }
    }

    private void resumeAudio() {
        if (player != null && !player.isPlaying()) {
            player.start();
            statusText.setText("繼續播放……");
            updateProgressLoop();
        }
    }

    private void updateProgressLoop() {
        if (player == null) return;

        try {
            int dur = player.getDuration();
            int pos = player.getCurrentPosition();

            if (dur > 0) {
                playbackSeek.setProgress((int) (pos / (double) dur * 1000));
            }

            updateTime();

            if (player.isPlaying()) {
                playbackSeek.postDelayed(this::updateProgressLoop, 500);
            }

        } catch (Exception ignored) {}
    }

    private void updateTime() {
        if (player == null) return;

        timeText.setText(
                formatTime(player.getCurrentPosition()) +
                " / " +
                formatTime(player.getDuration())
        );
    }

    private String formatTime(int ms) {
        int sec = Math.max(0, ms / 1000);

        return String.format(
                Locale.TAIWAN,
                "%02d:%02d",
                sec / 60,
                sec % 60
        );
    }

    private void saveAudioToDownloads() {
        showDownloadFormatDialog();
    }

    private void showDownloadFormatDialog() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "請先選擇或產生音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        File srt = pairedSrtFile(currentFile);
        boolean hasSrt = srt != null && srt.exists();

        String[] formats = hasSrt
                ? new String[]{
                        "WAV（無損原始音檔）",
                        "MP3（128 kbps，較小檔案）",
                        "SRT（字幕檔）",
                        "WAV＋SRT",
                        "MP3＋SRT"
                }
                : new String[]{
                        "WAV（無損原始音檔）",
                        "MP3（128 kbps，較小檔案）"
                };

        new AlertDialog.Builder(this)
                .setTitle("選擇下載格式")
                .setItems(formats, (d, which) -> {
                    if (!hasSrt) {
                        if (which == 0) saveWavToDownloads();
                        else saveMp3ToDownloads(false);
                        return;
                    }

                    switch (which) {
                        case 0:
                            saveWavToDownloads();
                            break;
                        case 1:
                            saveMp3ToDownloads(false);
                            break;
                        case 2:
                            saveSrtToDownloads();
                            break;
                        case 3:
                            saveWavAndSrtToDownloads();
                            break;
                        case 4:
                            saveMp3ToDownloads(true);
                            break;
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private Uri copyFileToDownloads(File source, String displayName, String mimeType) throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, displayName);
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        values.put(
                MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/AI文字轉新音檔"
        );

        Uri uri = getContentResolver().insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
        );

        if (uri == null) throw new IOException("建立下載檔失敗");

        try (
                InputStream in = new FileInputStream(source);
                OutputStream out = getContentResolver().openOutputStream(uri)
        ) {
            if (out == null) throw new IOException("無法寫入下載資料夾");

            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }
            out.flush();
        }

        return uri;
    }

    private void saveWavToDownloads() {
        try {
            String outName = ensureExtension(currentFile.getName(), ".wav");
            savedAudioUri = copyFileToDownloads(currentFile, outName, "audio/wav");
            statusText.setText("✅ WAV 已儲存到 Download/AI文字轉新音檔/\n" + outName);
            Toast.makeText(this, "WAV 音檔已儲存到下載資料夾", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            statusText.setText("WAV 儲存失敗：" + safeMessage(e));
        }
    }

    private void saveSrtToDownloads() {
        File srt = pairedSrtFile(currentFile);
        if (srt == null || !srt.exists()) {
            Toast.makeText(this, "這個音檔沒有對應的 SRT 字幕", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            copyFileToDownloads(srt, srt.getName(), "application/x-subrip");
            statusText.setText("✅ SRT 已儲存到 Download/AI文字轉新音檔/\n" + srt.getName());
            Toast.makeText(this, "SRT 字幕已儲存到下載資料夾", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            statusText.setText("SRT 儲存失敗：" + safeMessage(e));
        }
    }

    private void saveWavAndSrtToDownloads() {
        File srt = pairedSrtFile(currentFile);
        if (srt == null || !srt.exists()) {
            Toast.makeText(this, "找不到對應 SRT 字幕", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            copyFileToDownloads(currentFile, ensureExtension(currentFile.getName(), ".wav"), "audio/wav");
            copyFileToDownloads(srt, srt.getName(), "application/x-subrip");
            statusText.setText("✅ WAV＋SRT 已一起儲存到 Download/AI文字轉新音檔/");
            Toast.makeText(this, "WAV＋SRT 已完成下載", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            statusText.setText("WAV＋SRT 儲存失敗：" + safeMessage(e));
        }
    }

    private void saveMp3ToDownloads(boolean includeSrt) {
        statusText.setText(includeSrt ? "正在產生 MP3＋SRT……" : "正在轉換 MP3……");

        new Thread(() -> {
            File tempMp3 = null;

            try {
                String stem = stripAudioExtension(currentFile.getName());
                tempMp3 = new File(getCacheDir(), stem + "_" + System.currentTimeMillis() + ".mp3");
                wavToMp3(currentFile, tempMp3, 128);

                String outName = stem + ".mp3";
                Uri uri = copyFileToDownloads(tempMp3, outName, "audio/mpeg");
                savedAudioUri = uri;

                if (includeSrt) {
                    File srt = pairedSrtFile(currentFile);
                    if (srt == null || !srt.exists()) {
                        throw new IOException("找不到對應 SRT 字幕");
                    }
                    copyFileToDownloads(srt, srt.getName(), "application/x-subrip");
                }

                try { tempMp3.delete(); } catch (Exception ignored) {}

                runOnUiThread(() -> {
                    statusText.setText(
                            includeSrt
                                    ? "✅ MP3＋SRT 已儲存到 Download/AI文字轉新音檔/"
                                    : "✅ MP3 已儲存到 Download/AI文字轉新音檔/\n" + outName
                    );
                    Toast.makeText(
                            this,
                            includeSrt ? "MP3＋SRT 已完成下載" : "MP3 音檔已儲存到下載資料夾",
                            Toast.LENGTH_LONG
                    ).show();
                });

            } catch (Exception e) {
                String msg = safeMessage(e);
                runOnUiThread(() -> statusText.setText("MP3 轉換／儲存失敗：" + msg));
                if (tempMp3 != null && tempMp3.exists()) {
                    try { tempMp3.delete(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    private void wavToMp3(File wav, File mp3, int bitrateKbps) throws IOException {
        WavInfo info = parseWav(wav);

        if (info.audioFormat != 1) {
            throw new IOException("目前僅支援 PCM WAV 轉 MP3");
        }

        if (info.bitsPerSample != 16) {
            throw new IOException("目前僅支援 16-bit WAV 轉 MP3");
        }

        if (info.channels < 1 || info.channels > 2) {
            throw new IOException("目前僅支援單聲道或雙聲道");
        }

        if (info.sampleRate <= 0) {
            throw new IOException("WAV 採樣率異常");
        }

        AndroidLame encoder = new LameBuilder()
                .setInSampleRate(info.sampleRate)
                .setOutChannels(info.channels)
                .setOutBitrate(bitrateKbps)
                .setOutSampleRate(info.sampleRate)
                .setQuality(5)
                .build();

        byte[] pcmBytes = new byte[8192];
        short[] left = new short[4096];
        short[] right = new short[4096];
        byte[] mp3Buffer = new byte[(int) (7200 + left.length * 2 * 1.25)];

        try (
                RandomAccessFile raf = new RandomAccessFile(wav, "r");
                BufferedOutputStream out = new BufferedOutputStream(
                        new FileOutputStream(mp3),
                        8192
                )
        ) {
            raf.seek(info.dataOffset);
            long remain = info.dataSize;

            while (remain > 0) {
                int want = (int) Math.min(pcmBytes.length, remain);
                int read = raf.read(pcmBytes, 0, want);

                if (read <= 0) break;

                int frameBytes = info.channels * 2;
                int usable = read - (read % frameBytes);
                int frames = usable / frameBytes;

                for (int frame = 0; frame < frames; frame++) {
                    int base = frame * frameBytes;

                    short l = (short) (
                            (pcmBytes[base] & 0xff) |
                            (pcmBytes[base + 1] << 8)
                    );

                    left[frame] = l;

                    if (info.channels == 2) {
                        int rBase = base + 2;
                        right[frame] = (short) (
                                (pcmBytes[rBase] & 0xff) |
                                (pcmBytes[rBase + 1] << 8)
                        );
                    } else {
                        right[frame] = l;
                    }
                }

                int encoded = encoder.encode(
                        left,
                        right,
                        frames,
                        mp3Buffer
                );

                if (encoded < 0) {
                    throw new IOException("MP3 編碼失敗，錯誤碼：" + encoded);
                }

                if (encoded > 0) {
                    out.write(mp3Buffer, 0, encoded);
                }

                remain -= read;
            }

            int flushed = encoder.flush(mp3Buffer);

            if (flushed < 0) {
                throw new IOException("MP3 收尾失敗，錯誤碼：" + flushed);
            }

            if (flushed > 0) {
                out.write(mp3Buffer, 0, flushed);
            }

            out.flush();

        } finally {
            try {
                encoder.close();
            } catch (Exception ignored) {
            }
        }

        if (!mp3.exists() || mp3.length() <= 0) {
            throw new IOException("MP3 檔案沒有成功產生");
        }
    }

    private void showShareFormatDialog() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "請先選擇或產生音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        File srt = pairedSrtFile(currentFile);
        boolean hasSrt = srt != null && srt.exists();

        String[] formats = hasSrt
                ? new String[]{
                        "WAV",
                        "MP3（128 kbps）",
                        "SRT 字幕",
                        "WAV＋SRT",
                        "MP3＋SRT"
                }
                : new String[]{"WAV", "MP3（128 kbps）"};

        new AlertDialog.Builder(this)
                .setTitle("選擇分享格式")
                .setItems(formats, (dialog, which) -> {
                    if (!hasSrt) {
                        if (which == 0) prepareWavForShare();
                        else prepareMp3ForShare(false);
                        return;
                    }

                    switch (which) {
                        case 0:
                            prepareWavForShare();
                            break;
                        case 1:
                            prepareMp3ForShare(false);
                            break;
                        case 2:
                            prepareSrtForShare();
                            break;
                        case 3:
                            prepareWavAndSrtForShare();
                            break;
                        case 4:
                            prepareMp3ForShare(true);
                            break;
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void prepareWavForShare() {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "找不到音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Uri uri = copyAudioToDownloadsForShare(
                    currentFile,
                    ensureExtension(currentFile.getName(), ".wav"),
                    "audio/wav"
            );
            shareUri(uri, "audio/wav");
        } catch (Exception e) {
            statusText.setText("WAV 分享準備失敗：" + safeMessage(e));
        }
    }

    private void prepareSrtForShare() {
        File srt = pairedSrtFile(currentFile);
        if (srt == null || !srt.exists()) {
            Toast.makeText(this, "找不到對應 SRT 字幕", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Uri uri = copyAudioToDownloadsForShare(
                    srt,
                    srt.getName(),
                    "application/x-subrip"
            );
            shareUri(uri, "application/x-subrip");
        } catch (Exception e) {
            statusText.setText("SRT 分享準備失敗：" + safeMessage(e));
        }
    }

    private void prepareWavAndSrtForShare() {
        File srt = pairedSrtFile(currentFile);
        if (srt == null || !srt.exists()) {
            Toast.makeText(this, "找不到對應 SRT 字幕", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            ArrayList<Uri> uris = new ArrayList<>();
            uris.add(copyAudioToDownloadsForShare(
                    currentFile,
                    ensureExtension(currentFile.getName(), ".wav"),
                    "audio/wav"
            ));
            uris.add(copyAudioToDownloadsForShare(
                    srt,
                    srt.getName(),
                    "application/x-subrip"
            ));
            shareUris(uris);
        } catch (Exception e) {
            statusText.setText("WAV＋SRT 分享準備失敗：" + safeMessage(e));
        }
    }

    private void prepareMp3ForShare(boolean includeSrt) {
        if (currentFile == null || !currentFile.exists()) {
            Toast.makeText(this, "找不到音檔", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText(includeSrt ? "正在準備 MP3＋SRT 分享檔……" : "正在準備 MP3 分享檔……");

        new Thread(() -> {
            File tempMp3 = null;

            try {
                String stem = stripAudioExtension(currentFile.getName());
                tempMp3 = new File(
                        getCacheDir(),
                        stem + "_share_" + System.currentTimeMillis() + ".mp3"
                );

                wavToMp3(currentFile, tempMp3, 128);

                Uri mp3Uri = copyAudioToDownloadsForShare(
                        tempMp3,
                        stem + ".mp3",
                        "audio/mpeg"
                );

                File finalTempMp3 = tempMp3;

                if (includeSrt) {
                    File srt = pairedSrtFile(currentFile);
                    if (srt == null || !srt.exists()) {
                        throw new IOException("找不到對應 SRT 字幕");
                    }

                    Uri srtUri = copyAudioToDownloadsForShare(
                            srt,
                            srt.getName(),
                            "application/x-subrip"
                    );

                    ArrayList<Uri> uris = new ArrayList<>();
                    uris.add(mp3Uri);
                    uris.add(srtUri);

                    runOnUiThread(() -> {
                        statusText.setText("✅ MP3＋SRT 分享檔已準備完成");
                        shareUris(uris);
                    });
                } else {
                    runOnUiThread(() -> {
                        statusText.setText("✅ MP3 分享檔已準備完成");
                        shareUri(mp3Uri, "audio/mpeg");
                    });
                }

                try { finalTempMp3.delete(); } catch (Exception ignored) {}

            } catch (Exception e) {
                String msg = safeMessage(e);
                runOnUiThread(() -> statusText.setText("MP3 分享準備失敗：" + msg));

                if (tempMp3 != null && tempMp3.exists()) {
                    try { tempMp3.delete(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    private Uri copyAudioToDownloadsForShare(
            File source,
            String displayName,
            String mimeType
    ) throws IOException {

        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, displayName);
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        values.put(
                MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/AI文字轉新音檔"
        );

        Uri uri = getContentResolver().insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
        );

        if (uri == null) {
            throw new IOException("無法建立分享音檔");
        }

        try (
                InputStream in = new FileInputStream(source);
                OutputStream out = getContentResolver().openOutputStream(uri)
        ) {
            if (out == null) {
                throw new IOException("無法寫入分享音檔");
            }

            byte[] buffer = new byte[8192];
            int len;

            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }

            out.flush();
        }

        return uri;
    }

    private void shareUri(Uri uri, String mimeType) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType(mimeType);
        shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(
                shareIntent,
                "分享音檔"
        ));
    }


    private void shareUris(ArrayList<Uri> uris) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
        shareIntent.setType("*/*");
        shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(
                shareIntent,
                "分享音檔與字幕"
        ));
    }

    private String stripAudioExtension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);

        if (lower.endsWith(".wav") || lower.endsWith(".mp3")) {
            return name.substring(0, name.length() - 4);
        }

        return name;
    }

    private String ensureExtension(String name, String extension) {
        if (name.toLowerCase(Locale.ROOT)
                .endsWith(extension.toLowerCase(Locale.ROOT))) {
            return name;
        }

        return stripAudioExtension(name) + extension;
    }

    private String safeMessage(Throwable throwable) {
        if (throwable == null) return "未知錯誤";

        String message = throwable.getMessage();

        if (message == null || message.trim().isEmpty()) {
            return throwable.getClass().getSimpleName();
        }

        return message;
    }

    private void shareAudio() {
        showShareFormatDialog();
    }

    private void saveArticle() {
        String text = getTextOrWarn();
        if (text == null) return;

        EditText name = new EditText(this);
        name.setHint("文章名稱");

        new AlertDialog.Builder(this)
                .setTitle("保存文章")
                .setView(name)
                .setPositiveButton("保存", (d, w) -> {
                    String n = name.getText().toString().trim();

                    if (n.isEmpty()) {
                        n = "文章_" + System.currentTimeMillis();
                    }

                    Set<String> names = new LinkedHashSet<>(
                            prefs.getStringSet("article_names", new LinkedHashSet<>())
                    );

                    names.add(n);

                    prefs.edit()
                            .putStringSet("article_names", names)
                            .putString("article_" + n, text)
                            .apply();

                    Toast.makeText(this, "文章已保存", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showSavedArticles() {
        Set<String> saved = prefs.getStringSet(
                "article_names",
                new LinkedHashSet<>()
        );

        if (saved == null || saved.isEmpty()) {
            Toast.makeText(this, "尚無已保存文章", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> names = new ArrayList<>(saved);
        Collections.sort(names);

        new AlertDialog.Builder(this)
                .setTitle("已保存文章")
                .setItems(
                        names.toArray(new String[0]),
                        (d, which) -> showArticleActions(names.get(which))
                )
                .setNegativeButton("關閉", null)
                .show();
    }

    private void showArticleActions(String name) {
        String[] actions = {"載入文章", "刪除文章"};

        new AlertDialog.Builder(this)
                .setTitle(name)
                .setItems(actions, (d, which) -> {
                    if (which == 0) {
                        String t = prefs.getString("article_" + name, "");
                        inputText.setText(t);
                        inputText.setSelection(inputText.length());

                    } else {
                        Set<String> names = new LinkedHashSet<>(
                                prefs.getStringSet("article_names", new LinkedHashSet<>())
                        );

                        names.remove(name);

                        prefs.edit()
                                .putStringSet("article_names", names)
                                .remove("article_" + name)
                                .apply();

                        Toast.makeText(this, "文章已刪除", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void saveRecent(String text) {
        List<String> items = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            String old = prefs.getString("recent_" + i, null);

            if (old != null && !old.equals(text)) {
                items.add(old);
            }
        }

        items.add(0, text);

        while (items.size() > 10) {
            items.remove(items.size() - 1);
        }

        SharedPreferences.Editor e = prefs.edit();

        for (int i = 0; i < 10; i++) {
            e.remove("recent_" + i);
        }

        for (int i = 0; i < items.size(); i++) {
            e.putString("recent_" + i, items.get(i));
        }

        e.apply();
    }

    private void showRecent() {
        List<String> texts = new ArrayList<>();
        List<String> labels = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            String t = prefs.getString("recent_" + i, null);

            if (t != null && !t.isEmpty()) {
                texts.add(t);
                labels.add(
                        t.length() > 35
                                ? t.substring(0, 35) + "…"
                                : t
                );
            }
        }

        if (texts.isEmpty()) {
            Toast.makeText(this, "尚無最近文字", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("最近使用文字")
                .setItems(
                        labels.toArray(new String[0]),
                        (d, which) -> {
                            inputText.setText(texts.get(which));
                            inputText.setSelection(inputText.length());
                        }
                )
                .setNegativeButton("關閉", null)
                .show();
    }

    private void refreshAudioList() {
        if (audioList == null) return;

        audioList.removeAllViews();

        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);

        if (dir == null || !dir.exists()) {
            audioList.addView(text("尚無音檔。", 14, false));
            return;
        }

        File[] files = dir.listFiles((d, n) ->
                n.toLowerCase(Locale.ROOT).endsWith(".wav") &&
                !n.startsWith("tmp_")
        );

        if (files == null || files.length == 0) {
            audioList.addView(text("尚無音檔。", 14, false));
            return;
        }

        Arrays.sort(
                files,
                (a, b) -> Long.compare(b.lastModified(), a.lastModified())
        );

        for (File file : files) {
            addAudioRow(file);
        }
    }

    private void addAudioRow(File file) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(8));

        TextView name = text(file.getName(), 14, true);
        box.addView(name);

        LinearLayout row1 = horizontal();

        Button play = button("播放");
        Button save = button("下載");
        Button share = button("分享");

        row1.addView(play, weight());
        row1.addView(save, weight());
        row1.addView(share, weight());

        box.addView(row1);

        LinearLayout row2 = horizontal();

        Button subtitle = button("SRT字幕");
        Button rename = button("改名");
        Button delete = button("刪除");

        row2.addView(subtitle, weight());
        row2.addView(rename, weight());
        row2.addView(delete, weight());

        box.addView(row2);

        play.setOnClickListener(v -> {
            savedAudioUri = null;
            loadPlayer(file);
            playAudio();
        });

        save.setOnClickListener(v -> {
            currentFile = file;
            savedAudioUri = null;
            showDownloadFormatDialog();
        });

        share.setOnClickListener(v -> {
            currentFile = file;
            savedAudioUri = null;
            showShareFormatDialog();
        });

        subtitle.setOnClickListener(v -> showSubtitleActions(file));
        rename.setOnClickListener(v -> renameAudio(file));
        delete.setOnClickListener(v -> deleteAudio(file));

        audioList.addView(box);
    }

    private void showSubtitleActions(File file) {
        File srt = pairedSrtFile(file);
        if (srt == null || !srt.exists()) {
            Toast.makeText(this, "這個音檔沒有對應 SRT 字幕", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] actions = {"下載 SRT", "分享 SRT"};

        new AlertDialog.Builder(this)
                .setTitle(srt.getName())
                .setItems(actions, (d, which) -> {
                    currentFile = file;
                    if (which == 0) saveSrtToDownloads();
                    else prepareSrtForShare();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void renameAudio(File file) {
        EditText input = new EditText(this);

        String old = file.getName();
        if (old.toLowerCase(Locale.ROOT).endsWith(".wav")) {
            old = old.substring(0, old.length() - 4);
        }

        input.setText(old);

        new AlertDialog.Builder(this)
                .setTitle("重新命名")
                .setView(input)
                .setPositiveButton("確定", (d, w) -> {
                    String name = input.getText().toString().trim();

                    if (name.isEmpty()) return;

                    name = name.replaceAll("[\\\\/:*?\"<>|]", "_");

                    File target = new File(
                            file.getParentFile(),
                            name + ".wav"
                    );

                    if (target.exists()) {
                        Toast.makeText(this, "已有同名檔案", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    File oldSrt = pairedSrtFile(file);
                    File targetSrt = new File(file.getParentFile(), name + ".srt");

                    if (file.renameTo(target)) {
                        if (oldSrt != null && oldSrt.exists()) {
                            if (targetSrt.exists()) targetSrt.delete();
                            oldSrt.renameTo(targetSrt);
                        }

                        if (currentFile != null && currentFile.equals(file)) {
                            currentFile = target;
                        }

                        refreshAudioList();

                    } else {
                        Toast.makeText(this, "重新命名失敗", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void deleteAudio(File file) {
        new AlertDialog.Builder(this)
                .setTitle("刪除音檔")
                .setMessage("確定刪除「" + file.getName() + "」？")
                .setPositiveButton("刪除", (d, w) -> {
                    if (currentFile != null && currentFile.equals(file)) {
                        if (player != null) {
                            try {
                                player.stop();
                            } catch (Exception ignored) {}

                            player.release();
                            player = null;
                        }

                        currentFile = null;

                        previewPauseButton.setEnabled(false);
        previewResumeButton.setEnabled(false);
        previewStopButton.setEnabled(true);

        playButton.setEnabled(false);
                        pauseButton.setEnabled(false);
                        resumeButton.setEnabled(false);
                                                    }

                    File pairedSrt = pairedSrtFile(file);
                    if (file.delete()) {
                        if (pairedSrt != null && pairedSrt.exists()) {
                            try { pairedSrt.delete(); } catch (Exception ignored) {}
                        }
                        refreshAudioList();
                    } else {
                        Toast.makeText(this, "刪除失敗", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setPadding(0, dp(6), 0, dp(6));

        if (bold) {
            v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }

        return v;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int v) {
        return (int) (
                v * getResources().getDisplayMetrics().density
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ttsReady && tts != null) {
            loadVoices();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }

        if (player != null) {
            player.release();
        }

        if (previewPlayer != null) {
            try { previewPlayer.release(); } catch (Exception ignored) {}
        }

        if (previewFile != null && previewFile.exists()) {
            try { previewFile.delete(); } catch (Exception ignored) {}
        }

        super.onDestroy();
    }
}
