package global.a009.aitts;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {

    private TextToSpeech tts;
    private EditText inputText;
    private Spinner voiceSpinner;
    private SeekBar rateSeek, pitchSeek, playbackSeek;
    private TextView statusText, charCount, timeText;
    private Button createButton, playButton, pauseButton, saveButton, recentButton;
    private final List<Voice> voices = new ArrayList<>();
    private MediaPlayer player;
    private File currentFile;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("aitts_v05", MODE_PRIVATE);
        setContentView(buildUi());
        initTts();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root);

        TextView title = text("AI 文字轉新音檔", 28, true);
        root.addView(title);

        TextView sub = text("V0.5 全新重作穩定版｜免費測試", 14, false);
        root.addView(sub);

        inputText = new EditText(this);
        inputText.setHint("把要朗讀的文字貼在這裡……");
        inputText.setGravity(Gravity.TOP);
        inputText.setMinHeight(dp(220));
        inputText.setText(prefs.getString("last_text", ""));
        root.addView(inputText, matchWrap());

        charCount = text(inputText.length() + " 字", 13, false);
        charCount.setGravity(Gravity.END);
        root.addView(charCount);

        inputText.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                charCount.setText(s.length() + " 字");
                prefs.edit().putString("last_text", s.toString()).apply();
            }
            public void afterTextChanged(Editable e) {}
        });

        LinearLayout articleRow = horizontal();
        saveButton = button("保存文章");
        recentButton = button("最近文字");
        articleRow.addView(saveButton, weight());
        articleRow.addView(recentButton, weight());
        root.addView(articleRow);

        root.addView(text("可用語音", 16, true));
        voiceSpinner = new Spinner(this);
        root.addView(voiceSpinner, matchWrap());

        root.addView(text("語速", 16, true));
        rateSeek = new SeekBar(this);
        rateSeek.setMax(150);
        rateSeek.setProgress(50);
        root.addView(rateSeek, matchWrap());

        root.addView(text("音調", 16, true));
        pitchSeek = new SeekBar(this);
        pitchSeek.setMax(100);
        pitchSeek.setProgress(50);
        root.addView(pitchSeek, matchWrap());

        Button preview = button("試聽前 500 字");
        createButton = button("產生完整音檔");
        root.addView(preview, matchWrap());
        root.addView(createButton, matchWrap());

        statusText = text("語音引擎初始化中……", 14, false);
        root.addView(statusText);

        root.addView(text("播放器", 20, true));
        playbackSeek = new SeekBar(this);
        playbackSeek.setMax(1000);
        playbackSeek.setProgress(0);
        root.addView(playbackSeek, matchWrap());

        timeText = text("00:00 / 00:00", 14, false);
        timeText.setGravity(Gravity.CENTER);
        root.addView(timeText);

        LinearLayout playRow = horizontal();
        playButton = button("播放");
        pauseButton = button("暫停");
        playButton.setEnabled(false);
        pauseButton.setEnabled(false);
        playRow.addView(playButton, weight());
        playRow.addView(pauseButton, weight());
        root.addView(playRow);

        TextView note = text("※ 本版不收費、不扣點、不登入、不需 API Key，直接使用 Android 手機內建 TTS。", 12, false);
        root.addView(note);

        preview.setOnClickListener(v -> previewText());
        createButton.setOnClickListener(v -> createAudio());
        playButton.setOnClickListener(v -> playAudio());
        pauseButton.setOnClickListener(v -> pauseAudio());
        saveButton.setOnClickListener(v -> saveArticle());
        recentButton.setOnClickListener(v -> showRecent());

        playbackSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (player != null) {
                    int dur = player.getDuration();
                    player.seekTo((int)(dur * (seekBar.getProgress() / 1000.0)));
                    updateTime();
                }
            }
        });

        return scroll;
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                statusText.setText("TTS 語音引擎啟動失敗。");
                return;
            }

            int lang = tts.setLanguage(Locale.TAIWAN);
            if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                statusText.setText("手機尚未安裝繁體中文語音資料。");
                return;
            }

            loadVoices();
            statusText.setText("語音引擎已就緒。");
        });
    }

    private void loadVoices() {
        voices.clear();
        Set<Voice> set = tts.getVoices();
        if (set != null) {
            for (Voice v : set) {
                Locale l = v.getLocale();
                if (l != null && "zh".equals(l.getLanguage())) {
                    voices.add(v);
                }
            }
        }

        Collections.sort(voices, Comparator.comparing(Voice::getName));

        List<String> labels = new ArrayList<>();
        if (voices.isEmpty()) {
            labels.add("系統預設中文語音");
        } else {
            for (Voice v : voices) {
                labels.add(v.getName() + "｜" + v.getLocale().toLanguageTag());
            }
        }

        voiceSpinner.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
        ));
    }

    private void applyTtsSettings() {
        tts.setSpeechRate(0.5f + rateSeek.getProgress() / 100f);
        tts.setPitch(0.5f + pitchSeek.getProgress() / 100f);

        if (!voices.isEmpty()) {
            int pos = voiceSpinner.getSelectedItemPosition();
            if (pos >= 0 && pos < voices.size()) {
                tts.setVoice(voices.get(pos));
            }
        }
    }

    private String getTextOrWarn() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "請先輸入文字", Toast.LENGTH_SHORT).show();
            return null;
        }
        return text;
    }

    private void previewText() {
        String text = getTextOrWarn();
        if (text == null) return;

        applyTtsSettings();
        String preview = text.length() > 500 ? text.substring(0, 500) : text;
        tts.stop();
        tts.speak(preview, TextToSpeech.QUEUE_FLUSH, null, "preview");
        statusText.setText("正在試聽……");
    }

    private void createAudio() {
        String text = getTextOrWarn();
        if (text == null) return;

        applyTtsSettings();

        File dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (dir == null) {
            statusText.setText("無法建立音檔目錄。");
            return;
        }
        if (!dir.exists()) dir.mkdirs();

        currentFile = new File(dir, "AI語音_" + System.currentTimeMillis() + ".wav");
        String id = "tts_" + System.currentTimeMillis();

        createButton.setEnabled(false);
        statusText.setText("正在產生音檔……");

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}

            @Override public void onDone(String utteranceId) {
                runOnUiThread(() -> {
                    createButton.setEnabled(true);
                    statusText.setText("完成：" + currentFile.getName());
                    loadPlayer(currentFile);
                    saveRecent(text);
                });
            }

            @Override public void onError(String utteranceId) {
                runOnUiThread(() -> {
                    createButton.setEnabled(true);
                    statusText.setText("音檔產生失敗，請更換 TTS 語音後再試。");
                });
            }
        });

        int result = tts.synthesizeToFile(text, null, currentFile, id);
        if (result == TextToSpeech.ERROR) {
            createButton.setEnabled(true);
            statusText.setText("無法開始產生音檔。");
        }
    }

    private void loadPlayer(File file) {
        try {
            if (player != null) {
                player.release();
            }
            player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.prepare();

            playButton.setEnabled(true);
            pauseButton.setEnabled(true);
            playbackSeek.setProgress(0);
            updateTime();

            player.setOnCompletionListener(mp -> {
                playbackSeek.setProgress(1000);
                updateTime();
            });
        } catch (Exception e) {
            statusText.setText("播放器載入失敗：" + e.getMessage());
        }
    }

    private void playAudio() {
        if (player == null) return;
        player.start();
        statusText.setText("正在播放……");
        updateProgressLoop();
    }

    private void pauseAudio() {
        if (player != null && player.isPlaying()) {
            player.pause();
            statusText.setText("已暫停。");
            updateTime();
        }
    }

    private void updateProgressLoop() {
        if (player == null) return;
        try {
            int dur = player.getDuration();
            int pos = player.getCurrentPosition();
            if (dur > 0) playbackSeek.setProgress((int)(pos / (double)dur * 1000));
            updateTime();
            if (player.isPlaying()) {
                playbackSeek.postDelayed(this::updateProgressLoop, 500);
            }
        } catch (Exception ignored) {}
    }

    private void updateTime() {
        if (player == null) return;
        timeText.setText(formatTime(player.getCurrentPosition()) + " / " + formatTime(player.getDuration()));
    }

    private String formatTime(int ms) {
        int sec = Math.max(0, ms / 1000);
        return String.format(Locale.TAIWAN, "%02d:%02d", sec / 60, sec % 60);
    }

    private void saveArticle() {
        String text = getTextOrWarn();
        if (text == null) return;

        EditText name = new EditText(this);
        name.setHint("文章名稱");

        new AlertDialog.Builder(this)
                .setTitle("保存文章")
                .setView(name)
                .setPositiveButton("保存", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) n = "文章_" + System.currentTimeMillis();
                    prefs.edit().putString("saved_" + n, text).apply();
                    Toast.makeText(this, "文章已保存", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void saveRecent(String text) {
        for (int i = 8; i >= 0; i--) {
            String old = prefs.getString("recent_" + i, null);
            if (old != null) prefs.edit().putString("recent_" + (i + 1), old).apply();
        }
        prefs.edit().putString("recent_0", text).apply();
    }

    private void showRecent() {
        List<String> texts = new ArrayList<>();
        List<String> labels = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            String t = prefs.getString("recent_" + i, null);
            if (t != null && !t.isEmpty()) {
                texts.add(t);
                labels.add(t.length() > 35 ? t.substring(0, 35) + "…" : t);
            }
        }

        if (texts.isEmpty()) {
            Toast.makeText(this, "尚無最近文字", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("最近文字")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    inputText.setText(texts.get(which));
                    inputText.setSelection(inputText.length());
                })
                .setNegativeButton("關閉", null)
                .show();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setPadding(0, dp(6), 0, dp(6));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (player != null) {
            player.release();
        }
        super.onDestroy();
    }
}
