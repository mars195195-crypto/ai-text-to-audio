AI文字轉新音檔 V0.5 全新重作穩定版
================================

這一版不是從 V0.4.2 繼續修補，而是重新建立。

重作原則：
1. 移除 AndroidX
2. 移除 Material Components
3. dependencies 保持空白
4. UI 改用 Android 原生 View
5. 合法 package：global.a009.aitts
6. Java 17
7. Gradle 8.9
8. Android Gradle Plugin 8.7.3
9. compileSdk / targetSdk 35
10. GitHub Actions 直接從專案根目錄編譯，不需要 ZIP 解壓縮步驟

目前核心功能：
- 文字輸入
- 繁體中文 TTS
- 選擇手機可用中文聲音
- 語速
- 音調
- 試聽前 500 字
- 產生 WAV 音檔
- 播放
- 暫停
- 播放進度
- 保存文章
- 最近文字
- 不收費
- 不登入
- 不扣點
- 不需要 API Key

重要：
這版先以「穩定成功編譯 APK」為優先，
暫時拿掉長文多段 WAV 自動合併。
等 APK 成功裝機測試後，再加回長文合併與音檔管理功能。

GitHub 建議：
不要再把這份 ZIP 當單一檔案放進 Repository。
請把解壓縮後的所有內容上傳到 Repository 根目錄。
如果手機上傳資料夾不方便，可以先保留 ZIP，
再用現有 workflow 解壓，但最穩定仍是完整專案直接放在 repo 根目錄。
